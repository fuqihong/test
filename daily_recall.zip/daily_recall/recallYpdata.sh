
if [ $# <3 ] ; then
        echo "参数个数不正确"
        exit 1;
fi

spark-submit --master yarn-client --num-executors 8 --executor-memory 20G --executor-cores 6 --conf spark.default.parallelism=300 --py-files config.zip match_sample_data_main.py $1 $2 $3


spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip count_row_num_main.py $1 $2 $3
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip count_day_pay_main.py $1 $2 $3
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip count_day_open_main.py $1 $2 $3


spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip third_count_main.py $1 $2 $3
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip third_2_main.py $1 $2 $3
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip forth_1_main.py $1 $2 $3

spark-submit --master yarn-client --num-executors 13 --executor-memory 20G --executor-cores 8 --conf spark.akka.frameSize=300 --conf spark.default.parallelism=100 --py-files config.zip t01_main.py $1 $2 $3


spark-submit --master yarn-client --num-executors 8 --executor-memory 20G --executor-cores 6 --conf spark.default.parallelism=100 --py-files config.zip sum_main.py $1 $2 $3
/opt/anaconda3/bin/python send_emails.py $1 $2 $3 




























