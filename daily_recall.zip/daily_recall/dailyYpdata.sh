spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip count_row_num_main.py $1 $2
spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip count_day_pay_main.py $1 $2
spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip count_day_open_main.py $1 $2


spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip third_count_main.py $1 $2
spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip third_2_main.py $1 $2
spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip forth_1_main.py $1 $2

spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.akka.frameSize=300 --conf spark.default.parallelism=300 --py-files config.zip t01_main.py $1 $2
spark-submit --master yarn-client --num-executors 10 --executor-memory 28G --executor-cores 8 --conf spark.default.parallelism=300 --py-files config.zip sum_main.py $1 $2

/opt/anaconda3/bin/python send_emails.py $1 $2




























