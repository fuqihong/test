#!/usr/bin/python
# encoding:utf-8




from public_func import *

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')



def match_sample_data_func(key_cal, sys_argv, cal_type, config_dict, num_repartition):
    # check & create sc
    uu_id = config_dict['uu_id']
    uuid_list = uu_id.split(',')

    log_path = sys.argv[2]
    input_path = sys.argv[3]
    output_path =  input_path.replace('.csv', '').replace('/*', '')

    match_sample_data_path = config_dict['output_sample_data_path_pre'] + output_path

    log_dir = log_path.rsplit('/', 1)[0] + '/'
    file_dir = log_dir + key_cal +'_' 
    file_dir_success = file_dir + "success"

    if os.path.isfile(file_dir_success):
        sys.exit(0)
    else:
        try:
            os.popen('hadoop fs -rm -r  ' + match_sample_data_path)
        except:
            pass

    print(key_cal + "_sql_" + cal_type + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90)    

    sc = SparkContext(appName= key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)
  
    
    recallPath = config_dict['input_sample_path_pre'] + input_path
    recallRDDS= sc.textFile(recallPath)
    recallRDD = recallRDDS.map(lambda x: x.split(',')).map(lambda row: (row[0], row[1]))
    recallDf = hsqlContext.createDataFrame(recallRDD, ['idcard', 'recall_date'])
    hsqlContext.registerDataFrameAsTable(recallDf, "t_recall")
    
    
    df_count = hsqlContext.sql("select max(recall_date) as max_dt, count(1)  as all_samples_count from t_recall")
    df_count = df_count.toPandas()
    max_dt = str(df_count['max_dt'].values[0])
    
    sql_sent = """
    select a.id_pay, a.idcard, a.no_card, a.no_mec, a.mec_type, a.repay_tm, a.pay_result, a.amt, a.flag_error, 
    a.month, a.day, a.amt_s, b.recall_date
    from dwd.fea_personal_cfsl_loan_deduct_seq_daily a
    inner join t_recall b
    on a.idcard = b.idcard
    where a.dt <= '{max_dt}'
    and b.recall_date > a.repay_tm
    and b.idcard is not null
    """.format(max_dt = max_dt)
    
    matchDf = hsqlContext.sql(sql_sent)
    
    hsqlContext.registerDataFrameAsTable(matchDf, "df_match")
    df_match_count = hsqlContext.sql("select count(distinct idcard) as match_count from df_match")
    df_match_count = df_match_count.toPandas()
    
    feature_dict = matchDf.columns
    feature_dict_str = ','.join(feature_dict)
    feature_path = match_sample_data_path + '/dict'
    sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)


    
    save_path = match_sample_data_path + '/data'
    keySeconds = matchDf.rdd.map(lambda row: dropFrame(row))
    keySeconds.repartition(num_repartition).saveAsTextFile(save_path)
    
    
    print("samplesize: " + str(df_count.all_samples_count.values[0]))
    print("matchsamplesize: " + str(df_match_count.match_count.values[0]))
    print(key_cal + "_sql_" + cal_type + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90)
    
    sc.stop()
    
    

