
#!/usr/bin/python
# encoding:utf-8


from sqls.third_count_sql import *
from public_func import *

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')

mid_sql="""
select {uu_id},
mec_type,
datediff({cur_day},repay_tm) as day_pay,
no_mec,
pay_result,
count(1) as times 
from {mid_table}
group by 
{uu_id},
mec_type,datediff({cur_day},repay_tm),no_mec,pay_result
"""

cond_sql ="""
select {uu_id},
mec_type,
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 
then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay,
no_mec,
pay_result,
case when times > 100 then 5 when times > 50 then 4 when times > 10 then 3 when times > 0 then 2 else 1 end as times, count(1) as count_temp
from {mid_table}
 group by 
{uu_id},
mec_type,
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 
then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end,
no_mec,
pay_result,
case when times > 100 then 5 when times > 50 then 4 when times > 10 then 3 when times > 0 then 2 else 1 end
"""

groupby_sql = """
select {uu_id},
no_mec,
{groupby_key},
count(1) as temp_count 
from  {mid_table}
group by 
{uu_id},  no_mec, 
{groupby_key} 
"""


def third_count_func(key_cal,sys_argv, cal_type, config_dict, num_repartition):

    # check & create sc
    uu_id = config_dict['uu_id']
    uuid_list = uu_id.split(',')
    output_feature_hdfs_path, output_feature_dict_hdfs_path = get_path(key_cal, cal_type, sys_argv, config_dict)
    sc = SparkContext(appName= key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)

    # get origin table_name
    mid_table_name = get_ori_table(sys_argv,cal_type, config_dict, sc, hsqlContext)
    # mid df
    mid_df = hsqlContext.sql(mid_sql.format(uu_id = uu_id, cur_day = config_dict['cur_day'],mid_table = mid_table_name))

    mid_table_name = 'mid_table_name'
    hsqlContext.registerDataFrameAsTable(mid_df, mid_table_name)

    # cond df
    cond_df = hsqlContext.sql(cond_sql.format(uu_id = uu_id, mid_table = mid_table_name))

    mid_table_name = "cond_df"
    hsqlContext.registerDataFrameAsTable(cond_df, mid_table_name)

    groupby_key_1 = "mec_type, day_pay, pay_result, times"
    third_count_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_1, third_count_1_sql, hsqlContext)
    
    groupby_key_2 = "mec_type, pay_result, times"
    third_count_2_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_2, third_count_2_sql, hsqlContext)
    
    groupby_key_3 = "day_pay, pay_result, times "
    third_count_3_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_3, third_count_3_sql, hsqlContext)
    
    groupby_key_4 = "pay_result, times"
    third_count_4_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_4, third_count_4_sql, hsqlContext)
    
    third_count_fea_df = third_count_1_df.join(third_count_2_df, uuid_list).join(third_count_3_df,uuid_list).join(third_count_4_df, uuid_list)

    # save file
    save_fea_dict(sc, third_count_fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal, cal_type)

    sc.stop()

