
#!/usr/bin/python
# encoding:utf-8


from sqls.count_row_num_sql import *
from public_func import *

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')



mid_sql="""
select {uu_id},
no_mec as mec_no,
mec_type as goods_if_subbizcatname,
case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,
pay_result as pay_result,
row_number() over (partition by idcard order by repay_tm desc ) as row_num 
from {mid_table} 
"""


groupby_sql="""
select {uu_id},
mec_no,
{groupby_key}
case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end as row_num, 
count(1) as temp_count 
from  {mid_table}  
where row_num <= 100
group by  
{uu_id},
mec_no,
{groupby_key}
case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end

"""

def count_row_num_func(key_cal,sys_argv, cal_type, config_dict, num_repartition):

    # check & create sc
    uu_id = config_dict['uu_id']
    uuid_list = uu_id.split(',')
    output_feature_hdfs_path, output_feature_dict_hdfs_path = get_path(key_cal, cal_type, sys_argv, config_dict)
    sc = SparkContext(appName= key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)

    # get origin table_name
    mid_table_name = get_ori_table(sys_argv,cal_type, config_dict, sc, hsqlContext)
    # mid df
    mid_df = hsqlContext.sql(mid_sql.format(uu_id = uu_id, mid_table = mid_table_name))

    mid_table_name = 'mid_table_name'
    hsqlContext.registerDataFrameAsTable(mid_df, mid_table_name)

    groupby_key_4 = "goods_if_subbizcatname, pay_result, req_if_trademsg,"
    count_4_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_4, count_4_sql, hsqlContext)
    
    groupby_key_3_1 = "goods_if_subbizcatname,pay_result,"
    count_3_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_3_1, count_3_1_sql, hsqlContext)
    
    
    groupby_key_3_2 = "pay_result,req_if_trademsg, "
    count_3_2_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_3_2, count_3_2_sql,hsqlContext)
    
    
    groupby_key_2_1 = "goods_if_subbizcatname,"
    count_2_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_2_1, count_2_1_sql,hsqlContext)
    
    groupby_key_2_2 = "pay_result,"
    count_2_2_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_2_2, count_2_2_sql,hsqlContext)
    
    groupby_key_1 = ""
    count_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_1, count_1_sql,hsqlContext)
    
    count_row_num_fea_df = count_4_df.join(count_3_1_df, uuid_list).join(count_3_2_df, \
        uuid_list).join(count_2_1_df, uuid_list).join(count_2_2_df, \
        uuid_list).join(count_1_df, uuid_list)

    # fea sql

    # save file
    save_fea_dict(sc, count_row_num_fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal, cal_type)

    sc.stop()

