#!/usr/bin/python
# encoding:utf-8

import sys
import datetime
import os
#reload(sys)
#sys.setdefaultencoding('utf-8')


# for recall
input_sample_path_pre = '/user/tianchuang/spark/recall/'
output_sample_data_path_pre = '/user/qihong.fu/testtestrecall.db/'


# for daily
nowTime=datetime.date.today()
#yes_time = str(nowTime - datetime.timedelta(days=1))
yes_time = '2017-09-02'
input_table_name = "dwd.fea_personal_cfsl_loan_deduct_seq_daily where dt <= '{yes_time}' and idcard is not null ".format(yes_time = yes_time)

## out put feature_path 
feature_path = '/user/qihong.fu/{pre}feature-pool/fea_personal_cfsl_loan_daily/'
output_feature_hdfs_path_pre_daily = feature_path.format(pre  = 'testtest') + yes_time + '/'
output_feature_hdfs_path_pre_recall = feature_path.format(pre = 'dailyrecall-')




## daily and recall
cal_dict={"daily":{"uu_id": "idcard", 
                   "cur_day": "'" +  yes_time + "'",
                   "output_feature_path_pre": output_feature_hdfs_path_pre_daily,
                   "input_table_name": input_table_name}, 
          "recall":{"uu_id":"idcard,recall_date",
                    "cur_day": 'recall_date',
                    "output_feature_path_pre": output_feature_hdfs_path_pre_recall,
                    "input_sample_path_pre":input_sample_path_pre,
                    "output_sample_data_path_pre":output_sample_data_path_pre}}
repartitions_dict = {"daily":{"max_num":2000, "mid_num":500, "min_num": 100},
                     "recall":{"max_num":200, "mid_num":50, "min_num": 10}}


## for send email
sender = 'qihong.fu@yeepay.com'
receivers = ['qihong.fu@yeepay.com']
#receivers = ['qihong.fu@yeepay.com', 'xilin.zheng@tcredit.com','hui.zhang-4@tcredit.com'] 
smtpserver = 'smtp.yeepay.com'
username = 'qihong.fu'
password = 'WOlove080612_'



heads = \
          """
          <head>
                <meta charset="utf-8">
                <STYLE TYPE="text/css" MEDIA=screen>

                     table.dataframe {
                          border-collapse: collapse;
                          border: 2px solid #a19da2;
                          /*居中显示整个表格*/
                          margin: auto;
                     }

                     table.dataframe thead {
                          border: 2px solid #91c6e1;
                          background: #f1f1f1;
                          padding: 10px 10px 10px 10px;
                          color: #333333;
                     }

                     table.dataframe tbody {
                          border: 2px solid #91c6e1;
                          padding: 10px 10px 10px 10px;
                     }

                     table.dataframe tr {

                     }

                     table.dataframe th {
                          vertical-align: top;
                          font-size: 14px;
                          padding: 10px 10px 10px 10px;
                          color: #105de3;
                          font-family: arial;
                          text-align: center;
                     }

                     table.dataframe td {
                          text-align: center;
                          padding: 10px 10px 10px 10px;
                     }

                     body {
                          font-family: 宋体;
                     }

                     h1 {
                          color: #5db446
                     }

                     div.header h2 {
                          color: #0002e3;
                          font-family: 黑体;
                     }

                     div.content h2 {
                          text-align: center;
                          font-size: 28px;
                          text-shadow: 2px 2px 1px #de4040;
                          color: #fff;
                          font-weight: bold;
                          background-color: #008eb7;
                          line-height: 1.5;
                          margin: 20px 0;
                          box-shadow: 10px 10px 5px #888888;
                          border-radius: 5px;
                     }

                     h3 {
                          font-size: 22px;
                          background-color: rgba(0, 2, 227, 0.71);
                          text-shadow: 2px 2px 1px #de4040;
                          color: rgba(239, 241, 234, 0.99);
                          line-height: 1.5;
                     }

                     h4 {
                          color: #e10092;
                          font-family: 楷体;
                          font-size: 20px;
                          text-align: center;
                     }

                     td img {
                          /*width: 60px;*/
                          max-width: 300px;
                          max-height: 300px;
                     }

                </STYLE>
          </head>
          """

     # 构造模板的附件（100）
body_pre = \
          """
          <body>

          <div align="center" class="header">
                <!--标题部分的信息-->
                <h1 align="center">{title}</h1>
          </div>

          <hr>

          <div class="content">
                <!--正文内容-->
                <h2></h2>
"""
divs = \
"""
                <div>
        
                     <h4>{table_name}</h4>
                     {df_html}

                </div>
"""
body_suf = \
"""

                <hr>

                <p style="text-align: center">
                     —— over ——
                </p>
          </div>
          </body>
 """


