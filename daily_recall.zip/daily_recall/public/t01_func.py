
#!/usr/bin/python
# encoding:utf-8


from sqls.t01_sql import *
from public_func import *

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')


mid_sql="""
select {uu_id},
mec_type as goods_if_subbizcatname,
case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,
pay_result as pay_result,
amt as amt,
datediff({cur_day}, first_value(repay_tm) over(partition by no_mec,idcard order by repay_tm)) as day_open,
datediff({cur_day}, repay_tm) as day_pay,
row_number() over (partition by idcard order by repay_tm desc ) as row_num
from {mid_table}
"""

t01_cond_sql="""
select {uu_id},
goods_if_subbizcatname,
req_if_trademsg,
pay_result,
amt,
case when day_open <= 1 then 1 when day_open <= 7 then 2 when day_open <= 14 then 3 when day_open <= 21 then 4 when day_open <= 30 then 5 when day_open <= 90 then 6 when day_open <= 180 then 7 when day_open <= 360 then 8 else 9 end as day_open,
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay,
case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end as row_num,
1 as count_num
from {mid_table}
"""

def t01_func(key_cal,sys_argv, cal_type, config_dict, num_repartition):

    # check & create sc
    uu_id = config_dict['uu_id']
    output_feature_hdfs_path, output_feature_dict_hdfs_path = get_path(key_cal, cal_type, sys_argv, config_dict)
    sc = SparkContext(appName= key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)

    # get origin table_name
    mid_table_name = get_ori_table(sys_argv,cal_type, config_dict, sc, hsqlContext)
    # mid df
    mid_df = hsqlContext.sql(mid_sql.format(uu_id = uu_id, cur_day = config_dict['cur_day'],mid_table = mid_table_name))


    mid_table_name_1 = 'mid_table_name_1'
    hsqlContext.registerDataFrameAsTable(mid_df, mid_table_name_1)
    print(mid_table_name)

    # cond df
    t01_cond_df = hsqlContext.sql(t01_cond_sql.format(uu_id = uu_id, mid_table = mid_table_name_1))
    hsqlContext.registerDataFrameAsTable(t01_cond_df, "t01_cond_df")

    # fea sql
    t01_fea_sql = "select  " + uu_id + ', ' + t01_sql + "from t01_cond_df group by " + uu_id
    # fea df
    t01_fea_df = hsqlContext.sql(t01_fea_sql)

    # save file
    save_fea_dict(sc, t01_fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal, cal_type)

    sc.stop()

