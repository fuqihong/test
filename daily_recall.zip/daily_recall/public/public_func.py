#!/usr/bin/python
# encoding:utf-8

import sys
import datetime
import os
import time


def dropFrame(rows):
    x = ''
    for s in rows:
        x += str(s) + ','
    x = x[:-1]
    return x

# count distinct to sum
def count_distinct_2_sum(uu_id, mid_table_name, groupby_sql, groupby_key, count_sql, hsqlContext):
    countRowNumMidDf = hsqlContext.sql(groupby_sql.format(uu_id = uu_id, groupby_key = groupby_key, mid_table = mid_table_name))
    hsqlContext.registerDataFrameAsTable(countRowNumMidDf, "personal_cfsl_loan_deduct_seq_countRowNum_mid")
    count_fea_sql = "select  " +  uu_id + ',' + count_sql +\
                        " from personal_cfsl_loan_deduct_seq_countRowNum_mid aa  group by "\
                        + uu_id
    count_fea_df = hsqlContext.sql(count_fea_sql)
    return count_fea_df

# check the run status of the key_cal 
def run_status(key_cal, log_path, hdfs_fea_dir, hdfs_dict_dir):
    log_dir = log_path.rsplit('/', 1)[0] + '/'
    file_dir = log_dir + key_cal +'_' 
    file_dir_success = file_dir + "success"
    file_dir_run = file_dir+ "run"
    if os.path.isfile(file_dir_success):
        sys.exit(0)
    else:
        try:
             command_hdfs = hdfs_fea_dir + key_cal
             os.popen('hadoop fs -rm -r  ' + command_hdfs, 'r')
        except:
             pass
        try:
             command_hdfs = hdfs_dict_dir + key_cal
             os.popen('hadoop fs -rm -r  ' + command_hdfs, 'r')
        except:
             pass
        os.popen('rm -rf  ' + file_dir + '*') 
        os.mknod(file_dir_run)


def get_path_pre(sys_argv, config_dict):
    cal_type = sys_argv[1]
    log_path = sys_argv[2]
    output_feature_hdfs_path = config_dict['output_feature_path_pre']
    if cal_type == 'recall':
        input_path = sys_argv[3]
        output_path =  input_path.replace('.csv', '').replace('/*', '')
        output_feature_hdfs_path = output_feature_hdfs_path + output_path + '/'
    else:
        pass
    output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'
    return output_feature_hdfs_path, output_feature_dict_hdfs_path,log_path



def get_path(key_cal, cal_type, sys_argv, config_dict):
    output_feature_hdfs_path, output_feature_dict_hdfs_path,log_path = get_path_pre(sys_argv, config_dict)
    run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)
    print(key_cal + "_sql_" + cal_type + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90)
    return output_feature_hdfs_path, output_feature_dict_hdfs_path



# for recall
def recall_matchrdd(sc, hsqlContext, mid_table_name, match_sample_data_path):
    matchRddDict = sc.textFile(match_sample_data_path + '/dict/*')
    feature_list = matchRddDict.collect()
    feature_list = feature_list[0].split(',')
    matchRDDS = sc.textFile(match_sample_data_path + '/data/*')
    matchRDD = matchRDDS.map(lambda x: x.split(',')).map(lambda row: tuple([row[i] for i in range(len(feature_list))]))
    midDf = hsqlContext.createDataFrame(matchRDD,feature_list)
    hsqlContext.registerDataFrameAsTable(midDf, mid_table_name)

# get origin table
def get_ori_table(sys_argv, cal_type, config_dict, sc, hsqlContext):
    if cal_type == "daily":
        mid_table_name = config_dict['input_table_name']
    else:
        mid_table_name = "personal_cfsl_loan_deduct_seq"
        input_path = sys_argv[3]
        output_path = input_path.replace('.csv', '').replace('/*', '')        
        match_sample_data_path = config_dict['output_sample_data_path_pre'] + output_path  
        recall_matchrdd(sc, hsqlContext, mid_table_name, match_sample_data_path)
    return mid_table_name

# save the feature and dict to hdfs
def save_fea_dict(sc, fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal, cal_type):
    # save 
    feature_dict = fea_df.columns
    feature_dict_str = ','.join(feature_dict)
    feature_path = output_feature_dict_hdfs_path + key_cal
    sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)


    
    save_path = output_feature_hdfs_path + key_cal
    keySeconds = fea_df.rdd.map(lambda row: dropFrame(row))
    keySeconds.repartition(num_repartition).saveAsTextFile(save_path)
    print(key_cal + "_sql_" + cal_type + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90)
