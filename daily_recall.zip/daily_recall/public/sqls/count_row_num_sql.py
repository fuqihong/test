# encoding:utf-8 
count_1_sql="""
count(distinct case when row_num<=1 then mec_no else null end) as t01deizzz,
count(distinct case when row_num<=2 then mec_no else null end) as t01dejzzz,
count(distinct case when row_num<=3 then mec_no else null end) as t01dekzzz,
count(distinct case when row_num<=4 then mec_no else null end) as t01delzzz 
"""
count_2_1_sql="""
count(distinct case when row_num<=1 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01deizaz,
count(distinct case when row_num<=1 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01deizbz,
count(distinct case when row_num<=2 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01dejzaz,
count(distinct case when row_num<=2 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01dejzbz,
count(distinct case when row_num<=3 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01dekzaz,
count(distinct case when row_num<=3 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01dekzbz,
count(distinct case when row_num<=4 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01delzaz,
count(distinct case when row_num<=4 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01delzbz 
"""

count_2_2_sql="""
count(distinct case when row_num<=1 and pay_result =1 then mec_no else null end) as t01deizzc,
count(distinct case when row_num<=2 and pay_result =1 then mec_no else null end) as t01dejzzc,
count(distinct case when row_num<=3 and pay_result =1 then mec_no else null end) as t01dekzzc,
count(distinct case when row_num<=4 and pay_result =1 then mec_no else null end) as t01delzzc 
"""

count_3_1_sql="""
count(distinct case when row_num<=1 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01deizac,
count(distinct case when row_num<=1 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01deizbc,
count(distinct case when row_num<=2 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01dejzac,
count(distinct case when row_num<=2 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01dejzbc,
count(distinct case when row_num<=3 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01dekzac,
count(distinct case when row_num<=3 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01dekzbc,
count(distinct case when row_num<=4 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01delzac,
count(distinct case when row_num<=4 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01delzbc 
"""

count_3_2_sql="""
count(distinct case when row_num<=1 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deizza,
count(distinct case when row_num<=2 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dejzza,
count(distinct case when row_num<=2 and pay_result =0 and req_if_trademsg = 2 then mec_no else null end) as t01dejzzb,
count(distinct case when row_num<=3 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dekzza,
count(distinct case when row_num<=3 and pay_result =0 and req_if_trademsg = 2 then mec_no else null end) as t01dekzzb,
count(distinct case when row_num<=4 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01delzza,
count(distinct case when row_num<=4 and pay_result =0 and req_if_trademsg = 2 then mec_no else null end) as t01delzzb 
"""

count_4_sql="""
count(distinct case when row_num<=1 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deizba,
count(distinct case when row_num<=2 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dejzba,
count(distinct case when row_num<=3 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dekzaa,
count(distinct case when row_num<=3 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dekzba,
count(distinct case when row_num<=4 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01delzaa,
count(distinct case when row_num<=4 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01delzba,
count(distinct case when row_num<=4 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then mec_no else null end) as t01delzbb 
"""
