# encoding:utf-8 
pay_sql_1="""
count(distinct case when day_pay<=1 then mec_no else null end) as t01deazzz,
count(distinct case when day_pay<=2 then mec_no else null end) as t01debzzz,
count(distinct case when day_pay<=3 then mec_no else null end) as t01deczzz,
count(distinct case when day_pay<=4 then mec_no else null end) as t01dedzzz,
count(distinct case when day_pay<=5 then mec_no else null end) as t01deezzz,
count(distinct case when day_pay<=6 then mec_no else null end) as t01defzzz,
count(distinct case when day_pay<=7 then mec_no else null end) as t01degzzz,
count(distinct case when day_pay<=8 then mec_no else null end) as t01dehzzz 
"""
pay_sql_2_1="""
count(distinct case when day_pay<=2 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01debzbz,
count(distinct case when day_pay<=3 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01deczaz,
count(distinct case when day_pay<=3 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01deczbz,
count(distinct case when day_pay<=4 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01dedzaz,
count(distinct case when day_pay<=4 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01dedzbz,
count(distinct case when day_pay<=5 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01deezbz,
count(distinct case when day_pay<=5 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01deezaz,
count(distinct case when day_pay<=6 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01defzaz,
count(distinct case when day_pay<=6 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01defzbz,
count(distinct case when day_pay<=7 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01degzaz,
count(distinct case when day_pay<=7 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01degzbz,
count(distinct case when day_pay<=8 and goods_if_subbizcatname = 'cf' then mec_no else null end) as t01dehzaz,
count(distinct case when day_pay<=8 and goods_if_subbizcatname ='sl' then mec_no else null end) as t01dehzbz 
"""
pay_sql_2_2="""
count(distinct case when day_pay<=1 and pay_result =1 then mec_no else null end) as t01deazzc,
count(distinct case when day_pay<=2 and pay_result =1 then mec_no else null end) as t01debzzc,
count(distinct case when day_pay<=3 and pay_result =1 then mec_no else null end) as t01deczzc,
count(distinct case when day_pay<=4 and pay_result =1 then mec_no else null end) as t01dedzzc,
count(distinct case when day_pay<=5 and pay_result =1 then mec_no else null end) as t01deezzc,
count(distinct case when day_pay<=6 and pay_result =1 then mec_no else null end) as t01defzzc,
count(distinct case when day_pay<=7 and pay_result =1 then mec_no else null end) as t01degzzc,
count(distinct case when day_pay<=8 and pay_result =1 then mec_no else null end) as t01dehzzc 
"""

pay_sql_3_1="""
count(distinct case when day_pay<=2 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01debzbc,
count(distinct case when day_pay<=3 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01deczbc,
count(distinct case when day_pay<=4 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01dedzac,
count(distinct case when day_pay<=4 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01dedzbc,
count(distinct case when day_pay<=5 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01deezac,
count(distinct case when day_pay<=5 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01deezbc,
count(distinct case when day_pay<=6 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01defzac,
count(distinct case when day_pay<=6 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01defzbc,
count(distinct case when day_pay<=7 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01degzac,
count(distinct case when day_pay<=7 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01degzbc,
count(distinct case when day_pay<=8 and goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01dehzac,
count(distinct case when day_pay<=8 and goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01dehzbc 
"""
pay_sql_3_2="""
count(distinct case when day_pay<=2 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01debzza,
count(distinct case when day_pay<=3 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deczza,
count(distinct case when day_pay<=4 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dedzza,
count(distinct case when day_pay<=5 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deezza,
count(distinct case when day_pay<=6 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01defzza,
count(distinct case when day_pay<=7 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01degzza,
count(distinct case when day_pay<=8 and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dehzza,
count(distinct case when day_pay<=8 and pay_result =0 and req_if_trademsg = 2 then mec_no else null end) as t01dehzzb 
"""
pay_sql_4="""
count(distinct case when day_pay<=2 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01debzba,
count(distinct case when day_pay<=3 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deczba,
count(distinct case when day_pay<=4 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dedzba,
count(distinct case when day_pay<=5 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deezaa,
count(distinct case when day_pay<=5 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01deezba,
count(distinct case when day_pay<=6 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01defzaa,
count(distinct case when day_pay<=6 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01defzba,
count(distinct case when day_pay<=7 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01degzaa,
count(distinct case when day_pay<=7 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01degzba,
count(distinct case when day_pay<=8 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dehzaa,
count(distinct case when day_pay<=8 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dehzba 
"""

