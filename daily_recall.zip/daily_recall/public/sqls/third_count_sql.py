# encoding:utf-8 
third_count_1_sql="""
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 2 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td013,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 3 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td021,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 4 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td025,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 4 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td029,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 5 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td033,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 5 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td037,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 6 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td041,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 6 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td045,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 7 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td049,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 7 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td053,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 8 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td057,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 8 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td061,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 2 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td068,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 3 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td070,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 4 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td071,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 4 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td072,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 5 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td073,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 5 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td074,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 6 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td075,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 6 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td076,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 7 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td077,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 7 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td078,
count(distinct case when aa.mec_type = 'cf' and aa.day_pay <= 8 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td079,
count(distinct case when aa.mec_type = 'sl' and aa.day_pay <= 8 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td080 
"""

third_count_2_sql="""
count(distinct case when aa.mec_type = 'cf' and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td081,
count(distinct case when aa.mec_type = 'sl' and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td085,
count(distinct case when aa.mec_type = 'cf' and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td089,
count(distinct case when aa.mec_type = 'sl' and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td090 
"""

third_count_3_sql="""
count(distinct case when aa.day_pay <= 2 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td095,
count(distinct case when aa.day_pay <= 3 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td099,
count(distinct case when aa.day_pay <= 4 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td103,
count(distinct case when aa.day_pay <= 5 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td107,
count(distinct case when aa.day_pay <= 6 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td111,
count(distinct case when aa.day_pay <= 7 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td115,
count(distinct case when aa.day_pay <= 8 and aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td119,
count(distinct case when aa.day_pay <= 2 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td124,
count(distinct case when aa.day_pay <= 3 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td125,
count(distinct case when aa.day_pay <= 4 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td126,
count(distinct case when aa.day_pay <= 5 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td127,
count(distinct case when aa.day_pay <= 6 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td128,
count(distinct case when aa.day_pay <= 7 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td129,
count(distinct case when aa.day_pay <= 8 and aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td130 
"""
third_count_4_sql="""
count(distinct case when aa.pay_result = 0 and aa.times >= 2 then aa.no_mec else null end) as t03td131,
count(distinct case when aa.pay_result = 1 and aa.times >= 2 then aa.no_mec else null end) as t03td135 
"""
