#!/usr/bin/python
# encoding:utf-8

# @author:xilin.zheng

# @file:mid.py.py

# @time:2018/11/16 下午4:45
from public_func import *
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time

reload(sys)
sys.setdefaultencoding('utf-8')
import os


def forth_1_func(key_cal, sys_argv, cal_type, config_dict, num_repartition):
    # check & create sc
    uu_id = config_dict['uu_id']
    uuid_list = uu_id.split(',')
    output_feature_hdfs_path, output_feature_dict_hdfs_path = get_path(key_cal, cal_type, sys_argv, config_dict)
    sc = SparkContext(appName=key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)

    # get origin table_name
    mid_table_name = get_ori_table(sys_argv, cal_type, config_dict, sc, hsqlContext)
    # mid df
    mid_df = hsqlContext.sql("select * from {mid_table}".format(mid_table=mid_table_name))

    hsqlContext.registerDataFrameAsTable(mid_df, "personal_cfsl_loan_deduct_seq")

    uuid_df = hsqlContext.sql(
        "select {uu_id} , count(1) as count_num from {mid_table} group by {uu_id}".format(uu_id=uu_id,
                                                                                          mid_table=mid_table_name))
    uuid_df = uuid_df.drop('count_num')
    hsqlContext.registerDataFrameAsTable(uuid_df, "uuid_df")

    # t0400001 t0400002
    forth12InitDf = hsqlContext.sql(
        "select {uu_id}, no_mec,amt, "
        "datediff({cur_day}, repay_tm) as day_pay,"
        "repay_tm,pay_result,first_value(case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) "
        "over(partition by {uu_id},no_mec order by case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) first_faile_tm "
        "from personal_cfsl_loan_deduct_seq where repay_tm >= date_sub({cur_day},1)".format(cur_day=config_dict['cur_day'],uu_id=uu_id))

    hsqlContext.registerDataFrameAsTable(forth12InitDf, "forth_12_init_table")

    forth12MidDf = hsqlContext.sql(
        "select {uu_id},no_mec,"
        "max(amt) as max_amt_1,"
        "sum(case when pay_result = 1 then amt else null end) as sum_amt_1 "
        "from forth_12_init_table yy where repay_tm >= first_faile_tm group by {uu_id},no_mec".format(uu_id=uu_id));

    hsqlContext.registerDataFrameAsTable(forth12MidDf, "forth_12_mid_table")

    forth12Df = hsqlContext.sql(
        "select {uu_id},"
        "round(sum(max_amt_1), 2) as t0400001,"
        "round(sum(sum_amt_1), 2) as t0400002 "
        "from forth_12_mid_table aa group by {uu_id}".format(uu_id=uu_id))

    # t0400003 t0400004
    forth34InitDf = hsqlContext.sql(
        "select {uu_id}, no_mec,amt, "
        "datediff({cur_day}, repay_tm) as day_pay,"
        "repay_tm,pay_result,first_value(case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) "
        "over(partition by {uu_id},no_mec order by case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) first_faile_tm "
        "from personal_cfsl_loan_deduct_seq where repay_tm >= date_sub({cur_day},7)".format(cur_day=config_dict['cur_day'],uu_id=uu_id))

    hsqlContext.registerDataFrameAsTable(forth34InitDf, "forth_34_init_table")

    forth34MidDf = hsqlContext.sql(
        "select {uu_id},no_mec,"
        "max(amt) as max_amt_1,"
        "sum(case when pay_result = 1 then amt else null end) as sum_amt_1 "
        "from forth_34_init_table yy where repay_tm >= first_faile_tm group by {uu_id},no_mec".format(uu_id=uu_id));

    hsqlContext.registerDataFrameAsTable(forth34MidDf, "forth_34_mid_table")

    forth34Df = hsqlContext.sql(
        "select {uu_id},"
        "round(sum(max_amt_1), 2) as t0400003,"
        "round(sum(sum_amt_1), 2) as t0400004 "
        "from forth_34_mid_table aa group by {uu_id}".format(uu_id=uu_id))

    # t0400005 t0400006
    forth56InitDf = hsqlContext.sql(
        "select {uu_id}, no_mec,amt, "
        "datediff({cur_day}, repay_tm) as day_pay,"
        "repay_tm,pay_result,first_value(case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) "
        "over(partition by {uu_id},no_mec order by case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) first_faile_tm "
        "from personal_cfsl_loan_deduct_seq where repay_tm >= date_sub({cur_day},14)".format(cur_day=config_dict['cur_day'],uu_id=uu_id))

    hsqlContext.registerDataFrameAsTable(forth56InitDf, "forth_56_init_table")

    forth56MidDf = hsqlContext.sql(
        "select {uu_id},no_mec,"
        "max(amt) as max_amt_1,"
        "sum(case when pay_result = 1 then amt else null end) as sum_amt_1 "
        "from forth_56_init_table yy where repay_tm >= first_faile_tm group by {uu_id},no_mec".format(uu_id=uu_id));

    hsqlContext.registerDataFrameAsTable(forth56MidDf, "forth_56_mid_table")

    forth56Df = hsqlContext.sql(
        "select {uu_id},"
        "round(sum(max_amt_1), 2) as t0400005,"
        "round(sum(sum_amt_1), 2) as t0400006 "
        "from forth_56_mid_table aa group by {uu_id}".format(uu_id=uu_id))

    # t0400007 t0400008
    forth78InitDf = hsqlContext.sql(
        "select {uu_id}, no_mec,amt, "
        "datediff({cur_day}, repay_tm) as day_pay,"
        "repay_tm,pay_result,first_value(case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) "
        "over(partition by {uu_id},no_mec order by case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) first_faile_tm "
        "from personal_cfsl_loan_deduct_seq where repay_tm >= date_sub({cur_day},21)".format(cur_day=config_dict['cur_day'],uu_id=uu_id))

    hsqlContext.registerDataFrameAsTable(forth78InitDf, "forth_78_init_table")

    forth78MidDf = hsqlContext.sql(
        "select {uu_id},no_mec,"
        "max(amt) as max_amt_1,"
        "sum(case when pay_result = 1 then amt else null end) as sum_amt_1 "
        "from forth_78_init_table yy where repay_tm >= first_faile_tm group by {uu_id},no_mec".format(uu_id=uu_id));

    hsqlContext.registerDataFrameAsTable(forth78MidDf, "forth_78_mid_table")

    forth78Df = hsqlContext.sql(
        "select {uu_id},"
        "round(sum(max_amt_1), 2) as t0400007,"
        "round(sum(sum_amt_1), 2) as t0400008 "
        "from forth_78_mid_table aa group by {uu_id}".format(uu_id=uu_id))

    # t0400009 t0400010
    forth910InitDf = hsqlContext.sql(
        "select {uu_id}, no_mec,amt, "
        "datediff({cur_day}, repay_tm) as day_pay,"
        "repay_tm,pay_result,first_value(case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) "
        "over(partition by {uu_id},no_mec order by case when pay_result = 1 then cast(date_add(repay_tm,5475) as timestamp) else repay_tm end) first_faile_tm "
        "from personal_cfsl_loan_deduct_seq where repay_tm >= date_sub({cur_day},30)".format(cur_day=config_dict['cur_day'],uu_id=uu_id))

    hsqlContext.registerDataFrameAsTable(forth910InitDf, "forth_910_init_table")

    forth910MidDf = hsqlContext.sql(
        "select {uu_id},no_mec,"
        "max(amt) as max_amt_1,"
        "sum(case when pay_result = 1 then amt else null end) as sum_amt_1 "
        "from forth_910_init_table yy where repay_tm >= first_faile_tm group by {uu_id},no_mec".format(uu_id=uu_id));

    hsqlContext.registerDataFrameAsTable(forth910MidDf, "forth_910_mid_table")

    forth910Df = hsqlContext.sql(
        "select {uu_id},"
        "round(sum(max_amt_1), 2) as t0400009,"
        "round(sum(sum_amt_1), 2) as t0400010 "
        "from forth_910_mid_table aa group by {uu_id}".format(uu_id=uu_id))


    forth_1_fea_df = uuid_df.join(forth12Df, uuid_list, how="left_outer").join(forth34Df, uuid_list,how="left_outer").join(
        forth56Df, uuid_list, how="left_outer").join(forth78Df, uuid_list, how="left_outer").join(forth910Df, uuid_list,how="left_outer")
    save_fea_dict(sc, forth_1_fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal,
                  cal_type)

    sc.stop()


