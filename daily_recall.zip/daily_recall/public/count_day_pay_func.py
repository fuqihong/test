
#!/usr/bin/python
# encoding:utf-8


from sqls.count_day_pay_sql import *
from public_func import *

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')

mid_sql="""
select {uu_id},
no_mec as mec_no,
mec_type as goods_if_subbizcatname,
case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,
pay_result as pay_result,
datediff({cur_day}, repay_tm) as day_pay 
from {mid_table} 
{where_or_and} 
repay_tm >= date_sub({cur_day},360)
"""

groupby_sql = """
select {uu_id},
mec_no,
{groupby_key}
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay, 
 count(1) as temp_sql 
from  {mid_table}
group by 
{uu_id},
mec_no,
{groupby_key}
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end
"""

def count_day_pay_func(key_cal,sys_argv, cal_type, config_dict, num_repartition):

    # check & create sc
    uu_id = config_dict['uu_id']
    uuid_list = uu_id.split(',')
    output_feature_hdfs_path, output_feature_dict_hdfs_path = get_path(key_cal, cal_type, sys_argv, config_dict)
    sc = SparkContext(appName= key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)

    # get origin table_name
    mid_table_name = get_ori_table(sys_argv, cal_type, config_dict, sc, hsqlContext)
    # mid df
    where_or_and = ' where ' if 'where' not in mid_table_name else ' and '
    mid_df = hsqlContext.sql(mid_sql.format(uu_id = uu_id, cur_day = config_dict['cur_day'],
        mid_table = mid_table_name, where_or_and = where_or_and))

    mid_table_name = 'mid_table_name'
    hsqlContext.registerDataFrameAsTable(mid_df, mid_table_name)


    groupby_key_4 = "goods_if_subbizcatname, pay_result, req_if_trademsg,"
    pay_4_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_4, pay_sql_4,hsqlContext)
    
    groupby_key_3_1 = "goods_if_subbizcatname,pay_result,"
    pay_3_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_3_1, pay_sql_3_1,hsqlContext)
    
    
    groupby_key_3_2 = "pay_result,req_if_trademsg ,"
    pay_3_2_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_3_2, pay_sql_3_2, hsqlContext)
    
    
    groupby_key_2_1 = "goods_if_subbizcatname,"
    pay_2_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_2_1, pay_sql_2_1,hsqlContext)
    
    groupby_key_2_2 = "pay_result,"
    pay_2_2_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_2_2, pay_sql_2_2,hsqlContext)
    
    groupby_key_1 = ""
    pay_1_df = count_distinct_2_sum(uu_id, mid_table_name,groupby_sql, groupby_key_1, pay_sql_1,hsqlContext)




    count_day_pay_fea_df = pay_4_df.join(pay_3_1_df, uuid_list).join(pay_3_2_df, \
                    uuid_list).join(pay_2_1_df, uuid_list).join(pay_2_2_df, \
                    uuid_list).join(pay_1_df, uuid_list)


    # save file
    save_fea_dict(sc, count_day_pay_fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal, cal_type)

    sc.stop()

