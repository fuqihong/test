#!/usr/bin/python
# encoding:utf-8

# @author:xilin.zheng

# @file:mid.py.py

# @time:2018/11/16 下午4:45
from public_func import *
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
reload(sys)
sys.setdefaultencoding('utf-8')
import os 


def third_2_func(key_cal,sys_argv, cal_type, config_dict, num_repartition):
    # check & create sc
    uu_id = config_dict['uu_id']
    uuid_list = uu_id.split(',')
    output_feature_hdfs_path, output_feature_dict_hdfs_path = get_path(key_cal, cal_type, sys_argv, config_dict)
    sc = SparkContext(appName= key_cal + "_sql_" + cal_type)
    hsqlContext = HiveContext(sc)

    # get origin table_name
    mid_table_name = get_ori_table(sys_argv,cal_type, config_dict, sc, hsqlContext)
    # mid df
    mid_df = hsqlContext.sql("select * from {mid_table}".format(mid_table = mid_table_name))

    
    hsqlContext.registerDataFrameAsTable(mid_df, "personal_cfsl_loan_deduct_seq")

    uuid_df = hsqlContext.sql("select {uu_id} , count(1) as count_num from {mid_table} group by {uu_id}".format(uu_id=uu_id, mid_table = mid_table_name))
    uuid_df = uuid_df.drop('count_num')
    hsqlContext.registerDataFrameAsTable(uuid_df, "uuid_df")


    # 扣款失败后距离下一次成功的天数，按idcard
    kksbNextDayAADf = hsqlContext.sql(
        "select mec_type,{uu_id},repay_tm from personal_cfsl_loan_deduct_seq  where pay_result = 0".format(uu_id = uu_id))

    hsqlContext.registerDataFrameAsTable(kksbNextDayAADf, "kksbNextDay_aa")

    kksbNextDayBBInitDf = hsqlContext.sql(
        "select {uu_id},bb.repay_tm,bb.pay_result,bb.mec_type,lag(bb.pay_result,1) over(partition \
        by {uu_id},bb.mec_type order by bb.repay_tm) as last_result from personal_cfsl_loan_deduct_seq bb".format(uu_id = uu_id))

    hsqlContext.registerDataFrameAsTable(kksbNextDayBBInitDf, "kksbNextDay_bb_init")

    kksbNextDayBBDf = hsqlContext.sql("select {uu_id},"
                                  "bb.repay_tm,bb.mec_type,"
                                  "lag(bb.repay_tm,1,'2000-01-01') over(partition by {uu_id},bb.mec_type order by bb.repay_tm) as last_repay_tm "
                                  "from kksbNextDay_bb_init bb where bb.pay_result = 1 and bb.last_result = 0".format(uu_id = uu_id))

    hsqlContext.registerDataFrameAsTable(kksbNextDayBBDf, "kksbNextDay_bb")

    aa_uuid = ','.join(['aa.' + uuid  for uuid in uuid_list])
    on_uuid = ' and '.join(['aa.' + uuid + '=bb.' + uuid for uuid in uuid_list])
    kksbNextDayDf = hsqlContext.sql("select {aa_uuid},"
                                "max(case when aa.mec_type = 'cf' then datediff(bb.repay_tm,aa.repay_tm) else null end) as t03td136,"
                                "max(case when aa.mec_type = 'sl' then datediff(bb.repay_tm,aa.repay_tm) else null end )as t03td137,"
                                "min(case when aa.mec_type = 'cf' then datediff(bb.repay_tm,aa.repay_tm) else null end) as t03td139,"
                                "min(case when aa.mec_type = 'sl' then datediff(bb.repay_tm,aa.repay_tm) else null end )as t03td140,"
                                "round(avg(case when aa.mec_type = 'cf' then datediff(bb.repay_tm,aa.repay_tm) else null end),2) as t03td142,"
                                "round(avg(case when aa.mec_type = 'sl' then datediff(bb.repay_tm,aa.repay_tm) else null end ),2)as t03td143 "
                                "from kksbNextDay_aa aa join kksbNextDay_bb bb on {on_uuid} and aa.mec_type = bb.mec_type "
                                "where aa.repay_tm > bb.last_repay_tm and aa.repay_tm < bb.repay_tm group by {aa_uuid}".format(aa_uuid = aa_uuid, on_uuid = on_uuid))

    hsqlContext.registerDataFrameAsTable(kksbNextDayDf, "kksbNextDayDf_table")
    third_1_df = uuid_df.join(kksbNextDayDf, uuid_list, 'left_outer')
    
    #扣款失败后距离下一次成功的天数，按idcard
    kksbNextDayAADf2 = hsqlContext.sql("select {uu_id},aa.repay_tm from personal_cfsl_loan_deduct_seq aa where aa.pay_result = 0".format(uu_id= uu_id))
    
    hsqlContext.registerDataFrameAsTable(kksbNextDayAADf2, "kksbNextDay_cc")
    
    kksbNextDayBBInitDf2 = hsqlContext.sql(
       "select {uu_id},bb.repay_tm,bb.pay_result,lag(bb.pay_result,1) over(partition by {uu_id} order by bb.repay_tm) as last_result \
       from personal_cfsl_loan_deduct_seq bb".format(uu_id = uu_id))
    
    hsqlContext.registerDataFrameAsTable(kksbNextDayBBInitDf2, "kksbNextDay_dd_init")
    
    kksbNextDayBBDf2 = hsqlContext.sql("select {uu_id},"
        "bb.repay_tm,"
        "lag(bb.repay_tm,1,'2000-01-01') over(partition by {uu_id} order by bb.repay_tm) as last_repay_tm "
        "from kksbNextDay_dd_init bb where bb.pay_result = 1 and bb.last_result = 0".format(uu_id = uu_id))
    
    hsqlContext.registerDataFrameAsTable(kksbNextDayBBDf2, "kksbNextDay_dd")
    
    kksbNextDayDf2 = hsqlContext.sql("select {aa_uuid},"
        "max(datediff(bb.repay_tm,aa.repay_tm)) as t03td138,"
        "min(datediff(bb.repay_tm,aa.repay_tm)) as t03td141,"
        "round(avg(datediff(bb.repay_tm,aa.repay_tm)),2) as t03td144 "
        "from kksbNextDay_cc aa join kksbNextDay_dd bb on {on_uuid} "
        "where aa.repay_tm > bb.last_repay_tm and aa.repay_tm < bb.repay_tm group by {aa_uuid}".format(aa_uuid = aa_uuid, on_uuid = on_uuid))
    
    
    third_2_df = third_1_df.join(kksbNextDayDf2, uuid_list, 'left_outer')
    
    
    # 最后一次扣款因为余额不足失败后扣款次数求和
    zhyckkCountInitDf = hsqlContext.sql("select {uu_id},"
        "repay_tm,"
        "mec_type,"
        "pay_result,"
        "first_value(repay_tm) over(partition by {uu_id},mec_type order by case when pay_result = 1 then cast(date_sub(repay_tm,5475)  as timestamp) else repay_tm end desc) as last_fail_tm "
        "from personal_cfsl_loan_deduct_seq".format(uu_id = uu_id))
    
    hsqlContext.registerDataFrameAsTable(zhyckkCountInitDf, "zhyckkCount_init")
    
    zhyckkCountDf = hsqlContext.sql("select {uu_id},"
        "sum(case when aa.mec_type = 'cf' then 1 else 0 end) as t03td145,"
        "sum(case when aa.mec_type = 'sl' then 1 else 0 end) as t03td146 "
        "from zhyckkCount_init aa where aa.pay_result = 1 and aa.repay_tm > last_fail_tm group by {uu_id}".format(uu_id = uu_id))
    
    third_3_df = third_2_df.join(zhyckkCountDf, uuid_list, 'left_outer')
    
    #third_3_df.show()
    
    zhyckkCountInitDf2 = hsqlContext.sql("select {uu_id},"
        "repay_tm,"
        "pay_result,"
        "first_value(repay_tm) over(partition by {uu_id} order by case when pay_result = 1 then cast(date_sub(repay_tm,5475)  as timestamp) else repay_tm end desc) as last_fail_tm "
        "from personal_cfsl_loan_deduct_seq".format(uu_id = uu_id))
    
    hsqlContext.registerDataFrameAsTable(zhyckkCountInitDf2, "zhyckkCount2_init")
    
    zhyckkCountDf2 = hsqlContext.sql("select {uu_id},"
    "count(1) as t03td147 "
    "from zhyckkCount2_init aa where aa.pay_result = 1 and aa.repay_tm > last_fail_tm group by {uu_id}".format(uu_id = uu_id))
    
    third_4_df = third_3_df.join(zhyckkCountDf2, uuid_list, 'left_outer')
    
    #third_4_df.show()
    #
    # # 当前逾期机构数 最近一次扣款为扣款失败机构数
    # # 当前履约机构数 最近一次扣款为扣款成功机构数
    #
    zjyckkOrgCountInitDf = hsqlContext.sql("select {uu_id}, "
        "no_mec,"
        "pay_result,"
        "row_number() over(partition by {uu_id},no_mec order by repay_tm desc) rn "
        "from personal_cfsl_loan_deduct_seq aa ".format(uu_id = uu_id))
    
    hsqlContext.registerDataFrameAsTable(zjyckkOrgCountInitDf, "zjyckkOrgCount_init")
    
    zjyckkOrgCountDf = hsqlContext.sql("select {uu_id}, "
        "count(distinct case when aa.pay_result = 0 then no_mec else null end) as t03td148,"
        "count(distinct case when aa.pay_result = 1 then no_mec else null end) as t03td149 "
        "from  zjyckkOrgCount_init aa where rn = 1 group by {uu_id}".format(uu_id = uu_id))
    
    third_5_df = third_4_df.join(zjyckkOrgCountDf, uuid_list, 'left_outer')
    #third_5_df.show()
    #
    # # 睡眠机构数 截止查询时间，用户6个月内无交易记录的机构数
    t03td150MidDf = hsqlContext.sql("select {uu_id}, "
    "no_mec as merchants,"
    "max(repay_tm) as last_pay_tm "
    "from personal_cfsl_loan_deduct_seq group by {uu_id},no_mec".format(uu_id = uu_id))
    
    hsqlContext.registerDataFrameAsTable(t03td150MidDf, "t03td150_mid")
    # 睡眠机构数 t03td150
    t03td150Df = hsqlContext.sql("select {uu_id},"
    "count(distinct case when datediff({cur_day}, last_pay_tm)>180 then merchants else null end) as t03td150 "
    "from t03td150_mid as med group by {uu_id}".format(cur_day = config_dict['cur_day'], uu_id = uu_id))
    
    third_6_df = third_5_df.join(t03td150Df, uuid_list, 'left_outer')
    
    #third_6_df.show()
    # # 最近1次 扣款失败(-客户余额不足) 金额
    # # 扣款失败(-除余额不足外其他客观原因)
    # # 扣款成功
    # # 全
    zjyckkAmountMidDf = hsqlContext.sql("select {uu_id},"
        "amt,"
        "case when pay_result = 1 then '1' "
        "when (pay_result = 0 and flag_error = '1') then '0' "
        "when (pay_result = 0 and flag_error regexp '2|3|4|5') then '-1'  else null end as trademsg,"
        "row_number() over(partition by {uu_id} order by repay_tm desc) as pay_order "
        "from personal_cfsl_loan_deduct_seq".format(uu_id = uu_id))
    
    
    hsqlContext.registerDataFrameAsTable(zjyckkAmountMidDf, "zjyckkAmount_mid")
    # 最近1次扣款金额表
    zjyckkAmountDf = hsqlContext.sql("select {uu_id},"
        "round(case when ot.trademsg = '0' then ot.amt else null end,2) as t03td151,"
        "round(case when ot.trademsg = '1' then ot.amt else null end,2) as t03td153,"
        "round(ot.amt,2) as t03td154 from zjyckkAmount_mid ot where ot.pay_order=1".format(uu_id = uu_id))
    
    third_2_fea_df = third_6_df.join(zjyckkAmountDf, uuid_list, 'left_outer')

    save_fea_dict(sc, third_2_fea_df, num_repartition, output_feature_dict_hdfs_path, output_feature_hdfs_path, key_cal, cal_type)
    
    sc.stop()

