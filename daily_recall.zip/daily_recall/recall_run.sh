set -e


if [ $# != 1 ] ; then
        echo "参数个数不正确"
        exit 1;
fi


log_fold=/var/log/pyspark/ypdata/recall/$1

if [ ! -d "$log_fold" ]; then
  mkdir $log_fold
fi

etl_time=`date +%Y%m%d%H%M%S`

log_path=$log_fold/${etl_time}.log
echo "tail -fn 200 $log_path"
echo "less $log_path | grep _sql"
rm -rf public/*pyc
zip -q -r config.zip public

nohup sh recallYpdata.sh recall  $log_path $1  >> ${log_path} 2>&1 &
