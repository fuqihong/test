# 该代码将daily 和 recall(回溯)整合在一起

## 主要优化

- 1、count distinct 转为 group by 2次后sum,具体函数参考public.public_func.count_dinstinct_2_sum 

- 2、各部分基本参数化(详见public.config.py)：
   
   - 2.1 将daily 和 recall 的 group by 中的'idcard' 和'idcard,recall_date'参数化

   - 2.2 将daily 和 recall 的  current 和 recall_date 参数化
   
   - 2.3 数据存储字典化。每次输出均有对应的字典，无需考虑各变量存储的顺序问题，以及未来对变量的增删改导致读取发生变化的问题

- 3、各部分基本模块化，包括读取数据，存储变量等，便于以后自动生成相关部分代码


- 4、优化失败后重跑相关机制
   
   - 4.1 失败后只需再次执行运行脚本，无需手动删除hdfs文件（解决hdfs目录已存在无法插入数据问题）

   - 4.2 失败后再重跑，会自动判断已完成的模块，不会重复再跑

- 5、添加邮件通知功能，执行完成后会自动发送邮件，显示各任务的耗时及变量相关地址

## daily 和 recall 的主要区别说明

- 1、运行时，recall需要传入回溯文件名，daily不需要（默认跑t+1的任务）

- 2、daily无需匹配回溯数据，recall需要根据回溯样本匹配回溯数据，并将回溯数据作为中间表

- 3、daily group by的id为idcard, recall group by的id为idcard和recall_date

- 4、按日期计算时，daily根据T+1的日期和业务发生时间计算时间差，recall根据recall_date和业务发生时间计算时间差

- 5、输出变量中，recall比daily多了recall_date

- 6、recall 计算量比 daily 小，在提交spark以及存储hdfs时参数不相同


## 参数约定说明

- 1、recall
    
    - 1.1. 原始回溯文件以.csv结尾，不同文件名不能重复，否则会和历史文件冲突
    
    - 1.2. 原始回溯文件第一列默认为idcard,第二列为recall_date
    
    - 1.3. 变量存储目录名为回溯文件名前缀（去掉.csv）
    
    - 1.4. 日志存储目录名为回溯文件名（不去掉.csv）
    
    - 1.5. 执行main函数时，传入的参数sys.argv分别为 ['{t01_}main.py', **'recall'**, $log_path, .csv]  

- 2、daily 

   - 2.1. 默认昨天时间(脚本运行时间-1day)，如果需要跑历史时间，则修改public.config.py文件中yes_time

   - 2.2. 变量存储目录为yes_time(%Y-%m-%d)
   
   - 2.3. 日志存储目录默认为sh脚本运行当天(%Y%m%d)，如需修改日志存储目录，执行 sh daily_run.sh 时传入参数即可（目前该部分和yes_time未同步）
   
   - 2.4. 执行main函数时，传入的参数sys.argv分别为 ['{t01_}main.py', **'daily'**, $log_path]  




## 运行示例
```shell
## daily
sh daily_run.sh

## recall(abc.csv 为用户提供的待回溯样本)
sh recall_run.sh abc.csv
```


## 代码结构示例

主目录为 sh执行脚本，以及各模块的main函数(可自动生成)

public目录为公有函数public_func，各模块的func函数，config配置,以及sqls目录

sqls目录为各模块的sql语句(非可执行脚本,可自动生成)

```
##目录结构示例

├── README.md
├── count_day_open_main.py
├── dailyYpdata.sh
├── daily_run.sh
├── public
│   ├── __init__.py
│   ├── config.py
│   ├── count_day_open_func.py
│   ├── public_func.py
│   ├── sqls
│   │   ├── __init__.py
│   │   ├── count_day_open_sql.py
├── recallYpdata.sh
├── recall_run.sh
├── send_emails.py
```
- config.zip 文件为run.sh将public文件夹打包。在Ypdata.sh中提交任务时 --pyfiles config.zip，作为main的依赖文件


## 代码调用流程说明(以daily 举例)


执行顺序 | 主要功能说明
---|---
daily_run.sh | 生成日志文件，传参
dailyYpdata.sh | 提交spark任务及相关参数，将系统参数传给main.py
main.py | 主模块，得到传参
func.py | 计算变量模块

## hdfs输入输出相关路径说明

daily 和 recall的主要区别如下：

- 1、recall回溯的中间表目录中，dict和data在同一层级。daily无该文件

- 2、输出变量目录，daily以日期为子目录，recall以输入回溯文件名为目录，（**去除.csv后缀**）



```trees
## daily结构示例

├── dwd.db(中间表)
│   ├──{fea_personal_cfsl_loan_deduct_seq_daily}
├── feature-pool(变量表)
│   ├── {fea_personal_cfsl_loan_daily}
│   │   ├── {2018-01-01}
│   │   │   ├──dict
│   │   │   │   ├──{t01}
│   │   │   ├──{t01}


## recall结构示例
/user/tianchuang/spark/recall/{abc.csv}(回溯原始数据目录)

├── dwd.db(原始中间表)
│   ├──{fea_personal_cfsl_loan_deduct_seq_daily}
├── recall.db(回溯得到的中间表)
│   ├──{fea_personal_cfsl_loan_deduct_seq_daily}
│   │   ├── {abc}
│   │   │   ├── data
│   │   │   ├── dict
├── recall-feature-pool(变量表)
│   ├── {fea_personal_cfsl_loan_daily}
│   │   ├── {abc}
│   │   │   ├──dict
│   │   │   │   ├──{t01}
│   │   │   ├──{t01}
```


## main.py部分 daily/recall 计算流程说明
daily | recall| 说明
---|---|---
null| match_sample_data_main.py| **recall独有，回溯匹配中间表数据**
count_row_num_main.py| count_row_num_main.py|
count_day_pay_main.py| count_day_pay_main.py|
count_day_open_main.py|count_day_open_main.py|
third_count_main.py|third_count_main.py|
third_2_main.py|third_2_main.py|
t01_main.py|t01_main.py| 第一批变量，sum，max,min
sum_main.py|sum_main.py| 依赖t01_main，计算第二批变量 svm_avg
send_emails.py|send_emails.py|发邮件

## func.py部分 **计算流程说明**

执行顺序| 相关函数
---|--- | 
判断该任务是否已经执行| public_func.get_path, send_emails
读中间表 | public_func.get_ori_table
生成相关条件 | 
根据sql计算变量 | 
保存变量及字典|public_func.save_fea_dict

## 日志文件说明

由该生生成目录可知：

- 1、每次相同任务的日志均在同一目录下

- 2、根据运行脚本的系统时间的不同，每次日志都会打在不同的文件中


```
## daily 目录
├── daily
│   ├── {20180101}
│   │   ├── {160701}.log
│   │   ├── t01.success

## recall 目录
├── recall
│   ├── {abc.csv}
│   │   ├── {20180101160701}.log
│   │   ├── t01.success
```

## 失败重跑机制

如果失败，则直接运行如下（和第一次运行一样）
```shell
## daily
sh daily_run.sh

## recall(abc.csv 为用户提供的待回溯样本)
sh recall_run.sh abc.csv
```

其原理如下：

根据日志文件中各main模块的.success文件进行判断，总体流程如下(以t01模块为例)：

- 1、执行 t01.func.py

   - 1.1.检查日志目录是否有{t01}.success 文件,如果有，则停止该函数执行

   - 1.2.打印 t01 run字段,并在日志目录下生成t01.run文件

   - 1.3.删除该模块在hdfs输出的数据

   - 1.4.如运行成功，打印t01 success字段

- 2、执行 send_email.py

   - 2.1.根据日志判断该模块有无运行（run）,是否运行成功（success）

   - 2.2.如果运行成功，则在日志目录下删除{t01} 相关文件，并新建t01.success文件

   - 2.3.如果运行失败，则在日志目录下删除{t01} 相关文件，并新建t01.fail文件

**如果想强制重新跑该模块，则需在日志目录下手动删除t01.success文件**

## 邮件通知功能

主要功能如下：

- 1、生成各模块的运行结果文件（详见失败重跑部分）

- 2、生成各模块的运行时间

- 3、回溯时额外计算样本的idcard匹配率

## public.config 相关参数说明

- daily

   - yes_time 时间参数，默认 T-1
   
   - input_table_name 为sql语句，结合yes_time,将中间表时间限制在yes_time前，配合func中读取中间表使用
   
   - output_feature_hdfs_path_pre_daily 为feature输出的hdfs目录前缀
   
   - uu_id 为group by及join的id,此处默认为'idcard' 

- recall

   - input_sample_path_pre 回溯样本hdfs目录前缀
   
   - output_sample_data_path_pre 回溯样本hdfs目录中间表地址前缀
   
   - output_feature_hdfs_path_pre_recall 回溯feature输出的hdfs目录前缀
   
   - uu_id 为group by及join的id,此处默认为'idcard,recall-date' 


## 提取变量示例

```python
# get feature name list
feature_dict = sc.textFile(path_fea_dict)
feature_list = feature_dict.collect()
feature_list = feature_list[0].split(',')

# get rdd with feature_list
feature_rdds = sc.textFile(path_fea_data)
feature_rdd = feature_rdds.map(lambda x: x.split(',')).map(lambda row: tuple([row[i] for i in feature_list]))  
```


