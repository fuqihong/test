
#!/usr/bin/python
# encoding:utf-8
from public.count_day_pay_func import count_day_pay_func
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')

from public.config import cal_dict,repartitions_dict

cal_type = sys.argv[1]
config_dict = cal_dict[cal_type]
key_cal = 'countDayPay'
num_repartition = repartitions_dict[cal_type]['min_num']
count_day_pay_func(key_cal,sys.argv, cal_type, config_dict, num_repartition)

