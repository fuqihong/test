
#!/usr/bin/python
# encoding:utf-8
from public.sum_func import sum_func
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')

from public.config import cal_dict,repartitions_dict

cal_type = sys.argv[1]
config_dict = cal_dict[cal_type]
key_cal = 'sum_avg'
key_cal_pre = 't01'
num_repartition = repartitions_dict[cal_type]['min_num']
sum_func(key_cal,key_cal_pre, sys.argv, cal_type, config_dict, num_repartition)

