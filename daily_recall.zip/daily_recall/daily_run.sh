set -e

if [ $# -eq 1 ];then
  etl_day=$1
else
  etl_day=`date +%Y%m%d`
fi

log_fold=/var/log/pyspark/ypdata/daily/${etl_day}

if [ ! -d "$log_fold" ]; then
  mkdir $log_fold
fi

etl_time=`date +%H%M%S`

log_path=$log_fold/${etl_time}.log
echo "tail -fn 200  $log_path"
echo "less $log_path | grep _sql"
rm -rf public/*pyc
zip -q -r config.zip public

nohup sh dailyYpdata.sh daily  $log_path  >> ${log_path} 2>&1 &
