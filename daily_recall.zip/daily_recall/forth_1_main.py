
#!/usr/bin/python
# encoding:utf-8
from public.forth_1_func import forth_1_func
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')

from public.config import cal_dict,repartitions_dict

cal_type = sys.argv[1]
config_dict = cal_dict[cal_type]
key_cal = 'forth_1'
num_repartition = repartitions_dict[cal_type]['min_num']
forth_1_func(key_cal,sys.argv, cal_type, config_dict, num_repartition)


