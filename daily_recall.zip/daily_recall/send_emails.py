
# coding: utf-8
import sys

import time
import os
import datetime
import pandas as pd
import numpy as np
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from public.config import *
from public.public_func import *


old_width = pd.get_option('display.max_colwidth')
pd.set_option('display.max_colwidth', -1)

# 三个参数：第一个为文本内容，第二个 plain 设置文本格式，第三个 utf-8 设置编码
message = MIMEMultipart('related')
# message = MIMEText('Python 邮件发送测试...', 'plain', 'utf-8')
message['From'] = sender    # 发送者
message['To'] =  ','.join(receivers)           # 接收者 

cal_type = sys.argv[1]
log_path = sys.argv[2]
config_dict = cal_dict[cal_type]
output_feature_hdfs_path, output_feature_dict_hdfs_path,log_path = get_path_pre(sys.argv, config_dict)


# 
subject = '【{cal_type} 通知】'.format(cal_type= cal_type) 
subject_suf = sys.argv[3] if cal_type == 'recall' else yes_time

subject = subject + subject_suf

## file_path

name_path = ['feature_hdfs_path','feature_dict_hdfs_path', 'log_path', 'sh_path']
value_path = [output_feature_hdfs_path, output_feature_dict_hdfs_path, log_path, os.getcwd()] 
if cal_type == 'recall':
    file_path = sys.argv[3]
    sample_data_hdfs_path = config_dict['input_sample_path_pre'] + file_path
    name_path = ['sample_data_hdfs_path'] + name_path
    value_path = [sample_data_hdfs_path] + value_path

df_path = pd.DataFrame({'value_path':value_path, 'name_path':name_path})
df_path_html = df_path.to_html(escape=False)


def get_log(key_grep, log_path):
    str_1 = os.popen("less " + log_path + " | grep  _sql | grep " + key_grep).read()
    a = str_1.replace(key_grep, ' ').replace('*', '').replace('_sql_', '').replace(cal_type, '').split("\n")
    a = [i for i in a if i != '']
    list_a = []
    list_b = []
    for i in range(len(a)):
        b = a[i].split("   ")
        list_a.append(b[0])
        list_b.append(b[1])
    df = pd.DataFrame({'lists': list_a, 'run_time': list_b})
    df['run_time'] = df['run_time'].astype('datetime64[ns]')
    return df

def get_run_time(log_path):
    df_run = get_log('run', log_path)
    df_success = get_log('success', log_path)
    df_run_result = df_run.merge(df_success, how = 'left', on = ['lists'], suffixes= ['_start', '_end'])
    df_run_result['run_time'] = df_run_result['run_time_end'] - df_run_result['run_time_start']
    df_run_result['status'] = np.where(pd.isnull(df_run_result['run_time']), 'fail', 'success')
    return df_run_result


df_run_result = get_run_time(log_path)
df_run_html = df_run_result.to_html(escape=False)

# run status and time
try:
    run_status = 'fail' if 'fail' in list(df_run_result['status'].unique()) else 'success'
    run_start = df_run_result['run_time_start'].min()
    run_end = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print(run_start)
    print(run_end)
    print(run_end - run_start)
except:
    run_status = 'fail'

subject = subject + ' 任务'  + run_status
message['Subject'] = Header(subject, 'utf-8')


log_dir = log_path.rsplit('/', 1)[0] + '/'

if df_run_result.shape[0] == 0:
    pass
else:
    for i in range(df_run_result.shape[0]):
        key_cal = df_run_result.ix[i, 0]
        file_dir = log_dir + key_cal +'_'
        #print(file_dir)
        #print('rm -rf  ' + file_dir + '*')  
        os.popen('rm -rf  ' + file_dir + '*')
        #print(file_dir +str(df_run_result.ix[i, 4]))
        os.popen('touch  ' + file_dir + str(df_run_result.ix[i, 4]))


### coverage -recall 
try:
    coverage_str =  os.popen("less " + log_path + " | grep " + "samplesize").read()
    coverage_list = coverage_str.replace(' ', '').split('\n')
    coverage_list = [i for i in coverage_list if i != '']
    df_coverage = pd.DataFrame({coverage_list[0].split(':')[0]:[coverage_list[0].split(':')[1]],
                             coverage_list[1].split(':')[0]:[coverage_list[1].split(':')[1]]} )
    df_coverage = df_coverage.astype(int)
    df_coverage['rate_coverage'] = round(df_coverage['matchsamplesize']/df_coverage['samplesize'], 2)
    df_coverage_html = df_coverage.to_html(escape=False)
except:
    df_coverage_html = pd.DataFrame([]).to_html(escape=False)



title = '大爷，{subject}'.format(subject=subject)

if cal_type == 'daily':
    body = body_pre.format(title = title) + \
       divs.format(table_name = '相关路径', df_html = df_path_html) + \
       divs.format(table_name = '运行时间', df_html = df_run_html) 

else:
    body = body_pre.format(title = title) + \
       divs.format(table_name = '相关路径', df_html = df_path_html) + \
       divs.format(table_name = '样本匹配覆盖度', df_html = df_coverage_html) + \
       divs.format(table_name = '运行时间', df_html = df_run_html)


#### 下部分无需修改
html_msg= "<html>" + heads + body  + "</html>"

content_html = MIMEText(html_msg, "html", "utf-8")
message.attach(content_html)




smtp = smtplib.SMTP()
smtp.connect('smtp.yeepay.com')
smtp.login(username, password)
smtp.sendmail(sender, receivers, message.as_string())
smtp.quit()





