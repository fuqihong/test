set -e


if [ $# != 1 ] ; then
        echo "参数个数不正确"
        exit 1;
fi


log_fold=/var/log/pyspark/ypdata/recall/$1

if [ ! -d "$log_fold" ]; then
  mkdir $log_fold
fi

etl_time=`date +%Y%m%d%H%M%S`

log_path=$log_fold/${etl_time}.log
echo $log_path

cp ../daily.bak/config/*sql.py config/
zip -q -r config.zip config

nohup sh recallYpdata.sh  $log_path $1  >> ${log_path} 2>&1 &
