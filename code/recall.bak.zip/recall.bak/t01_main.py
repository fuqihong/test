
#!/usr/bin/python
# encoding:utf-8
from config.config import output_sample_data_path_pre,output_feature_path_pre,run_status,dropFrame,count_distinct_2_sum
from config.t01_sql import t01_sql

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')


key_cal = 't01'
log_path = sys.argv[1]
input_path = sys.argv[2]
output_path =  input_path.replace('.csv', '').replace('/*', '')
output_feature_hdfs_path = output_feature_path_pre + output_path + '/'
output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)
match_sample_data_path = output_sample_data_path_pre + output_path

print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90

sc = SparkContext(appName= key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)
matchRDDS = sc.textFile(match_sample_data_path)

matchRDD = matchRDDS.map(lambda x: x.split(',')).map(lambda row: (
    row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11], row[12]))
midDf = hsqlContext.createDataFrame(matchRDD,
                                    ['id_pay', 'idcard', 'no_card', 'no_mec', 'mec_type', 'repay_tm', 'pay_result',
                                     'amt', 'flag_error', 'month', 'day', 'amt_s', 'recall_date'])

hsqlContext.registerDataFrameAsTable(midDf, "personal_cfsl_loan_deduct_seq")


# mid df
t01_mid_df = hsqlContext.sql("select idcard,recall_date,"
                           "mec_type as goods_if_subbizcatname,"
                           "case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,"
                           "pay_result as pay_result,"
                           "amt as amt,"
                           "datediff(recall_date, first_value(repay_tm) over(partition by no_mec,idcard order by repay_tm)) as day_open,"
                           "datediff(recall_date, repay_tm) as day_pay,"
                           "row_number() over (partition by idcard order by repay_tm desc ) as row_num "
                           "from personal_cfsl_loan_deduct_seq")

hsqlContext.registerDataFrameAsTable(t01_mid_df, "mid_df")


## t01 
# cond df
t01_cond_df = hsqlContext.sql("select idcard,recall_date,"
                           "goods_if_subbizcatname,"
                           "req_if_trademsg,"
                           "pay_result,"
                           "amt,"
                           "case when day_open <= 1 then 1 when day_open <= 7 then 2 when day_open <= 14 then 3 when day_open <= 21 then 4 when day_open <= 30 then 5 when day_open <= 90 then 6 when day_open <= 180 then 7 when day_open <= 360 then 8 else 9 end as day_open,"
                           "case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay,"
                           "case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end as row_num,"
                           "1 as count_num "
                           "from mid_df  ")
hsqlContext.registerDataFrameAsTable(t01_cond_df, "t01_cond_df")

# fea sql
t01_fea_sql = "select idcard,recall_date," + t01_sql + "from t01_cond_df group by idcard, recall_date"
# fea df
t01_fea_df = hsqlContext.sql(t01_fea_sql)



#hsqlContext.registerDataFrameAsTable(t01_fea_df, "t01_fea_df")

## sum_avg
#sum_avg_fea_sql = "select idcard, " + sum_avg_sql + "from t01_fea_df"

#sum_avg_fea_df = hsqlContext.sql(sum_avg_fea_sql)

## join
#t01_fea_all_df = t01_fea_df.join(sum_avg_fea_df, "idcard")


feature_dict = t01_fea_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path + key_cal
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)


# save 
save_path = output_feature_hdfs_path + key_cal
keySeconds = t01_fea_df.rdd.map(lambda row: dropFrame(row))
keySeconds.repartition(200).saveAsTextFile(save_path)

sc.stop()
print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
