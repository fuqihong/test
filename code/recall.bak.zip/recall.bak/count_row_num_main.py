#!/usr/bin/python
# encoding:utf-8

# @author:xilin.zheng

# @file:mid.py.py
# @time:2018/11/16 下午4:45
from config.count_row_num_sql import count_4_sql,count_3_1_sql,count_3_2_sql,count_2_1_sql,count_2_2_sql,count_1_sql
from config.config import output_sample_data_path_pre,output_feature_path_pre,run_status,dropFrame
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import pandas as pd
import os

reload(sys)
sys.setdefaultencoding('utf-8')


key_cal = 'countRowNum'
log_path = sys.argv[1]
input_path = sys.argv[2]
output_path =  input_path.replace('.csv', '').replace('/*', '')
output_feature_hdfs_path = output_feature_path_pre + output_path + '/'
output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)
match_sample_data_path = output_sample_data_path_pre + output_path



print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
sc = SparkContext(appName= key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)


matchRDDS = sc.textFile(match_sample_data_path)

matchRDD = matchRDDS.map(lambda x: x.split(',')).map(lambda row: (
    row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11], row[12]))
midDf = hsqlContext.createDataFrame(matchRDD,
                                    ['id_pay', 'idcard', 'no_card', 'no_mec', 'mec_type', 'repay_tm', 'pay_result',
                                     'amt', 'flag_error', 'month', 'day', 'amt_s', 'recall_date'])

hsqlContext.registerDataFrameAsTable(midDf, "personal_cfsl_loan_deduct_seq")

midsqlDf = hsqlContext.sql("select idcard,recall_date, "
                           "no_mec as mec_no,"
                           "mec_type as goods_if_subbizcatname,"
                           "case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,"
                           "pay_result as pay_result,"
                           "row_number() over (partition by idcard order by repay_tm desc ) as row_num "
                           "from  personal_cfsl_loan_deduct_seq")

hsqlContext.registerDataFrameAsTable(midsqlDf, "personal_cfsl_loan_deduct_seq_mid")

groupby_sql="""
select 
case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end as row_num, 
{groupby_key},
count(1) as temp_count 
from  personal_cfsl_loan_deduct_seq_mid 
where row_num <= 100
group by  
case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end,
{groupby_key}
"""

def count_distinct_2_sum(groupby_sql, groupby_key, count_sql):
    groupby_key_new = groupby_key + "idcard, mec_no, recall_date" 
    countRowNumMidDf = hsqlContext.sql(groupby_sql.format(groupby_key = groupby_key_new))
    hsqlContext.registerDataFrameAsTable(countRowNumMidDf, "personal_cfsl_loan_deduct_seq_countRowNum_mid")
    count_fea_sql = "select idcard,recall_date, " + count_sql + "from personal_cfsl_loan_deduct_seq_countRowNum_mid group by idcard, recall_date"
    count_fea_df = hsqlContext.sql(count_fea_sql)
    return count_fea_df

groupby_key_4 = "goods_if_subbizcatname, pay_result, req_if_trademsg,"
count_4_df = count_distinct_2_sum(groupby_sql, groupby_key_4, count_4_sql)

groupby_key_3_1 = "goods_if_subbizcatname,pay_result,"
count_3_1_df = count_distinct_2_sum(groupby_sql, groupby_key_3_1, count_3_1_sql)


groupby_key_3_2 = "pay_result,req_if_trademsg, "
count_3_2_df = count_distinct_2_sum(groupby_sql, groupby_key_3_2, count_3_2_sql)


groupby_key_2_1 = "goods_if_subbizcatname,"
count_2_1_df = count_distinct_2_sum(groupby_sql, groupby_key_2_1, count_2_1_sql)

groupby_key_2_2 = "pay_result,"
count_2_2_df = count_distinct_2_sum(groupby_sql, groupby_key_2_2, count_2_2_sql)

groupby_key_1 = ""
count_1_df = count_distinct_2_sum(groupby_sql, groupby_key_1, count_1_sql)

count_df = count_4_df.join(count_3_1_df, ["idcard", "recall_date"]).join(count_3_2_df, \
                ["idcard", "recall_date"]).join(count_2_1_df, ["idcard", "recall_date"]).join(count_2_2_df, \
                ["idcard", "recall_date"]).join(count_1_df, ["idcard", "recall_date"])


feature_dict = count_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path + key_cal
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)

save_path = output_feature_hdfs_path + key_cal
keys = count_df.rdd.map(lambda row: dropFrame(row))
keys.repartition(50).saveAsTextFile(save_path)

sc.stop()
print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
