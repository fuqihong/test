#!/usr/bin/python
# encoding:utf-8

from config.count_day_pay_sql import pay_sql_4, pay_sql_3_1, pay_sql_3_2, pay_sql_2_1, pay_sql_2_2, pay_sql_1
from config.config import output_sample_data_path_pre,output_feature_path_pre,run_status,dropFrame,count_distinct_2_sum
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import pandas as pd
reload(sys)
sys.setdefaultencoding('utf-8')
import os
key_cal = 'countDayPay'

log_path = sys.argv[1]
input_path = sys.argv[2]
output_path =  input_path.replace('.csv', '').replace('/*', '')
output_feature_hdfs_path = output_feature_path_pre + output_path + '/'
output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)
match_sample_data_path = output_sample_data_path_pre + output_path

print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90

sc = SparkContext(appName= key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)

matchRDDS = sc.textFile(match_sample_data_path)

matchRDD = matchRDDS.map(lambda x: x.split(',')).map(lambda row: (
    row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11], row[12]))
midDf = hsqlContext.createDataFrame(matchRDD,
                                    ['id_pay', 'idcard', 'no_card', 'no_mec', 'mec_type', 'repay_tm', 'pay_result',
                                     'amt', 'flag_error', 'month', 'day', 'amt_s', 'recall_date'])

hsqlContext.registerDataFrameAsTable(midDf, "personal_cfsl_loan_deduct_seq")



midsqlDf = hsqlContext.sql("select idcard,recall_date,"
                           "no_mec as mec_no,"
                           "mec_type as goods_if_subbizcatname,"
                           "case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,"
                           "pay_result as pay_result,"
                           "datediff(recall_date, repay_tm) as day_pay "
                           "from personal_cfsl_loan_deduct_seq where  repay_tm >= date_sub(recall_date,360)")

hsqlContext.registerDataFrameAsTable(midsqlDf, "personal_cfsl_loan_deduct_seq_mid")




groupby_sql = """
select idcard,
recall_date,
mec_no,
{groupby_key}
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay, 
 count(1) as temp_sql 
from  personal_cfsl_loan_deduct_seq_mid
group by 
idcard,
recall_date,
mec_no,
{groupby_key}
case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end
"""

groupby_key_4 = "goods_if_subbizcatname, pay_result, req_if_trademsg,"
pay_4_df = count_distinct_2_sum(groupby_sql, groupby_key_4, pay_sql_4,hsqlContext)

groupby_key_3_1 = "goods_if_subbizcatname,pay_result,"
pay_3_1_df = count_distinct_2_sum(groupby_sql, groupby_key_3_1, pay_sql_3_1,hsqlContext)


groupby_key_3_2 = "pay_result,req_if_trademsg ,"
pay_3_2_df = count_distinct_2_sum(groupby_sql, groupby_key_3_2, pay_sql_3_2, hsqlContext)


groupby_key_2_1 = "goods_if_subbizcatname,"
pay_2_1_df = count_distinct_2_sum(groupby_sql, groupby_key_2_1, pay_sql_2_1,hsqlContext)

groupby_key_2_2 = "pay_result,"
pay_2_2_df = count_distinct_2_sum(groupby_sql, groupby_key_2_2, pay_sql_2_2,hsqlContext)

groupby_key_1 = ""
pay_1_df = count_distinct_2_sum(groupby_sql, groupby_key_1, pay_sql_1,hsqlContext)




pay_df = pay_4_df.join(pay_3_1_df, ["idcard", "recall_date"]).join(pay_3_1_df, \
                ["idcard", "recall_date"]).join(pay_2_1_df, ["idcard", "recall_date"]).join(pay_2_2_df, \
                ["idcard", "recall_date"]).join(pay_1_df, ["idcard", "recall_date"])

feature_dict = pay_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path + key_cal
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)


save_path = output_feature_hdfs_path + key_cal
keys = pay_df.rdd.map(lambda row: dropFrame(row))
keys.repartition(50).saveAsTextFile(save_path)

sc.stop()


print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90


