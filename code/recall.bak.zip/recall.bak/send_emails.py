
# coding: utf-8
import sys


import os
import datetime
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from config.config import output_sample_data_path_pre,output_feature_path_pre,run_status,dropFrame,count_distinct_2_sum,heads,body_pre, body_suf, divs



log_path = sys.argv[1]
input_path = sys.argv[2]
output_path =  input_path.replace('.csv', '').replace('/*', '')
output_feature_hdfs_path = output_feature_path_pre + output_path + '/'
output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'

sender = 'qihong.fu@yeepay.com'
receivers = ['qihong.fu@yeepay.com']
#receivers = ['qihong.fu@yeepay.com', 'xilin.zheng@tcredit.com','hui.zhang-4@tcredit.com'] 
# 三个参数：第一个为文本内容，第二个 plain 设置文本格式，第三个 utf-8 设置编码
message = MIMEMultipart('related')
# message = MIMEText('Python 邮件发送测试...', 'plain', 'utf-8')
message['From'] = sender    # 发送者
message['To'] =  ','.join(receivers)           # 接收者 

smtpserver = 'smtp.yeepay.com'
username = 'qihong.fu'
password = 'WOlove080612_'




## file_path
old_width = pd.get_option('display.max_colwidth')
pd.set_option('display.max_colwidth', -1)
name_path = ['daily_feature_hdfs_path','daily_feature_dict_hdfs_path', 'log_path', 'sh_path']
path_value = [output_feature_hdfs_path, output_feature_dict_hdfs_path, log_path, os.getcwd()] 
df_path = pd.DataFrame({'value_path':path_value, 'name_path':name_path})
df_path_html = df_path.to_html(escape=False)

pd.set_option('display.max_colwidth', old_width)

subject = '【回溯通知】' + input_path
message['Subject'] = Header(subject, 'utf-8')




### coverage
try:
    coverage_str =  os.popen("less " + log_path + " | grep " + "samplesize").read()
    coverage_list = coverage_str.replace(' ', '').split('\n')
    coverage_list = [i for i in coverage_list if i != '']
    df_coverage = pd.DataFrame({coverage_list[0].split(':')[0]:[coverage_list[0].split(':')[1]],
                             coverage_list[1].split(':')[0]:[coverage_list[1].split(':')[1]]} )
    df_coverage = df_coverage.astype(int)
    df_coverage['rate_coverage'] = round(df_coverage['matchsamplesize']/df_coverage['samplesize'], 2)
    df_coverage_html = df_coverage.to_html(escape=False)
except:
    df_coverage_html = pd.DataFrame([]).to_html(escape=False)



### run time 
def get_log(key_grep):
    str_1 = os.popen("less " + log_path + " | grep  _sql | grep " + key_grep).read()
    a = str_1.replace(key_grep, ' ').replace('*', '').replace('_sql_daily', '').split("\n")
    a = [i for i in a if i != '']
    list_a = []
    list_b = []
    for i in range(len(a)):
        b = a[i].split("   ")
        list_a.append(b[0])
        list_b.append(b[1])
    df = pd.DataFrame({'lists': list_a, 'run_time': list_b})
    df['run_time'] = df['run_time'].astype('datetime64[ns]')
    return df
    
df_run = get_log('run')
df_success = get_log('success')
df_run_result = df_run.merge(df_success, how = 'left', on = ['lists'], suffixes= ['_start', '_end'])
df_run_result['run_time'] = df_run_result['run_time_end'] - df_run_result['run_time_start']
df_run_result['status'] = np.where(pd.isnull(df_run_result['run_time']), 'fail', 'success')
df_run_html = df_run_result.to_html(escape=False)

log_dir = log_path.rsplit('/', 1)[0] + '/'

if df_run_result.shape[0] == 0:
    pass
else:
    for i in range(df_run_result.shape[0]):
        key_cal = df_run_result.ix[i, 0]
        file_dir = log_dir + key_cal +'_'
        #print(file_dir)
        #print('rm -rf  ' + file_dir + '*')  
        os.popen('rm -rf  ' + file_dir + '*')
        #print(file_dir +str(df_run_result.ix[i, 4]))
        os.popen('touch  ' + file_dir + str(df_run_result.ix[i, 4]))

title = '大爷，[' + input_path + ']任务跑完了'
body = body_pre.format(title = title) + \
       divs.format(table_name = '相关路径', df_html = df_path_html) + \
       divs.format(table_name = '样本匹配覆盖度', df_html = df_coverage_html) + \
       divs.format(table_name = '运行时间', df_html = df_run_html)

#### 下部分无需修改
html_msg= "<html>" + heads + body  + "</html>"


content_html = MIMEText(html_msg, "html", "utf-8")
message.attach(content_html)




smtp = smtplib.SMTP()
smtp.connect('smtp.yeepay.com')
smtp.login(username, password)
smtp.sendmail(sender, receivers, message.as_string())
smtp.quit()




