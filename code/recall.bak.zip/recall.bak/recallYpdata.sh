
if [ $# <1 ] ; then
        echo "参数个数不正确"
        exit 1;
fi

spark-submit --master yarn-client --num-executors 15 --executor-memory 20G --executor-cores 6 --conf spark.default.parallelism=300 --py-files config.zip match_sample_data.py $1 $2


spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip count_row_num_main.py $1 $2
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip count_day_pay_main.py $1 $2
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip count_day_open_main.py $1 $2


spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip third_count_main.py $1 $2
spark-submit --master yarn-client --num-executors 8 --executor-memory 15G --executor-cores 6 --conf spark.default.parallelism=150 --py-files config.zip third_2.py $1 $2

spark-submit --master yarn-client --num-executors 12 --executor-memory 20G --executor-cores 8 --conf spark.akka.frameSize=300 --conf spark.default.parallelism=100 --py-files config.zip t01_main.py $1 $2

spark-submit --master yarn-client --num-executors 8 --executor-memory 20G --executor-cores 6 --conf spark.default.parallelism=100 --py-files config.zip sum_main.py $1 $2
/opt/anaconda3/bin/python send_emails.py $1 $2 




























