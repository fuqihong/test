#!/usr/bin/python
# encoding:utf-8

import sys
import datetime
import os
#reload(sys)
#sys.setdefaultencoding('utf-8')

input_sample_path_pre = '/user/tianchuang/spark/recall/'
output_sample_data_path_pre = '/user/qihong.fu/test-recall.db/'
output_feature_path_pre = '/user/qihong.fu/test-recall-feature-pool/fea_personal_cfsl_loan_daily/'


def dropFrame(rows):
    x = ''
    for s in rows:
        x += str(s) + ','
    x = x[:-1]
    return x

def count_distinct_2_sum(groupby_sql, groupby_key, count_sql, hsqlContext):
    countRowNumMidDf = hsqlContext.sql(groupby_sql.format(groupby_key = groupby_key))
    hsqlContext.registerDataFrameAsTable(countRowNumMidDf, "personal_cfsl_loan_deduct_seq_countRowNum_mid")
    count_fea_sql = "select idcard, recall_date,  " + count_sql + " from personal_cfsl_loan_deduct_seq_countRowNum_mid aa  group by idcard, recall_date"
    count_fea_df = hsqlContext.sql(count_fea_sql)
    return count_fea_df

def run_status(key_cal, log_path, hdfs_fea_dir, hdfs_dict_dir):
    log_dir = log_path.rsplit('/', 1)[0] + '/'
    file_dir = log_dir + key_cal +'_' 
    file_dir_success = file_dir + "success"
    file_dir_run = file_dir+ "run"
    if os.path.isfile(file_dir_success):
        sys.exit(0)
    else:
        try:
            command_hdfs = hdfs_fea_dir + key_cal
            os.popen('hadoop fs -rm -r  ' + command_hdfs, 'r')
        except:
            pass
        try:
            command_hdfs = hdfs_dict_dir + key_cal
            os.popen('hadoop fs -rm -r  ' + command_hdfs, 'r')
        except:
            pass
        os.popen('rm -rf  ' + file_dir + '*') 
        os.mknod(file_dir_run)


nowTime=datetime.date.today()
yes_time = str(nowTime - datetime.timedelta(days=1))
#yes_time = '2017-09-10'
input_mid_table_name = "dwd.fea_personal_cfsl_loan_deduct_seq_daily where dt <= '{yes_time}' and idcard is not null ".format(yes_time = yes_time)

output_feature_hdfs_path = '/user/qihong.fu/test-feature-pool/fea_personal_cfsl_loan_daily/' + yes_time + '/'
output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'


## for send email

heads = \
        """
        <head>
            <meta charset="utf-8">
            <STYLE TYPE="text/css" MEDIA=screen>

                table.dataframe {
                    border-collapse: collapse;
                    border: 2px solid #a19da2;
                    /*居中显示整个表格*/
                    margin: auto;
                }

                table.dataframe thead {
                    border: 2px solid #91c6e1;
                    background: #f1f1f1;
                    padding: 10px 10px 10px 10px;
                    color: #333333;
                }

                table.dataframe tbody {
                    border: 2px solid #91c6e1;
                    padding: 10px 10px 10px 10px;
                }

                table.dataframe tr {

                }

                table.dataframe th {
                    vertical-align: top;
                    font-size: 14px;
                    padding: 10px 10px 10px 10px;
                    color: #105de3;
                    font-family: arial;
                    text-align: center;
                }

                table.dataframe td {
                    text-align: center;
                    padding: 10px 10px 10px 10px;
                }

                body {
                    font-family: 宋体;
                }

                h1 {
                    color: #5db446
                }

                div.header h2 {
                    color: #0002e3;
                    font-family: 黑体;
                }

                div.content h2 {
                    text-align: center;
                    font-size: 28px;
                    text-shadow: 2px 2px 1px #de4040;
                    color: #fff;
                    font-weight: bold;
                    background-color: #008eb7;
                    line-height: 1.5;
                    margin: 20px 0;
                    box-shadow: 10px 10px 5px #888888;
                    border-radius: 5px;
                }

                h3 {
                    font-size: 22px;
                    background-color: rgba(0, 2, 227, 0.71);
                    text-shadow: 2px 2px 1px #de4040;
                    color: rgba(239, 241, 234, 0.99);
                    line-height: 1.5;
                }

                h4 {
                    color: #e10092;
                    font-family: 楷体;
                    font-size: 20px;
                    text-align: center;
                }

                td img {
                    /*width: 60px;*/
                    max-width: 300px;
                    max-height: 300px;
                }

            </STYLE>
        </head>
        """

    # 构造模板的附件（100）
body_pre = \
        """
        <body>

        <div align="center" class="header">
            <!--标题部分的信息-->
            <h1 align="center">{title}</h1>
        </div>

        <hr>

        <div class="content">
            <!--正文内容-->
            <h2></h2>
"""
divs = \
"""
            <div>
      
                <h4>{table_name}</h4>
                {df_html}

            </div>
"""
body_suf = \
"""

            <hr>

            <p style="text-align: center">
                —— over ——
            </p>
        </div>
        </body>
 """

