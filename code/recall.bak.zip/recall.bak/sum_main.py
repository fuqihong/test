
#!/usr/bin/python
# encoding:utf-8


from config.config import output_sample_data_path_pre,output_feature_path_pre,run_status,dropFrame,count_distinct_2_sum
from config.sum_sql import sum_avg_sql

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')


key_cal = 'sum_avg'
log_path = sys.argv[1]
input_path = sys.argv[2]
output_path =  input_path.replace('.csv', '').replace('/*', '')
output_feature_hdfs_path = output_feature_path_pre + output_path + '/'
output_feature_dict_hdfs_path = output_feature_hdfs_path + 'dict/'
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)
match_sample_data_path = output_sample_data_path_pre + output_path


print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90

sc = SparkContext(appName= key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)

key_cal_pre = 't01'

## read data from t01
# get sum_t01 feature name
sum_avg_sql_list = sum_avg_sql.split('ELSE', ) 
sum_pre_list = [i.split('/')[0].replace(' ', '')   for i in sum_avg_sql_list[1:]]
sum_suf_list = [i.split('/')[1][:len(sum_pre_list[0])]   for i in sum_avg_sql_list[1:]]
sum_feature_name = list(set(sum_pre_list + sum_suf_list))
sum_feature_name = ['idcard', 'recall_date'] + sum_feature_name

# get t01 dict 
feature_dict = sc.textFile(output_feature_dict_hdfs_path + key_cal_pre)
feature_list = feature_dict.collect()
feature_list = feature_list[0].split(',')
sum_feature_index_list = [feature_list.index(i) for i in sum_feature_name]

# get t01 rdd with sum_feature_name
sum_feature = sc.textFile(output_feature_hdfs_path + key_cal_pre)
sum_feature_rdd = sum_feature.map(lambda x: x.split(',')).map(lambda row: tuple([row[i] for i in sum_feature_index_list]))

sum_feature_df = hsqlContext.createDataFrame(sum_feature_rdd, sum_feature_name)
hsqlContext.registerDataFrameAsTable(sum_feature_df, "sum_feature_df")




## sum_avg
sum_avg_fea_sql = "select idcard, recall_date, " + sum_avg_sql + " from sum_feature_df"

sum_avg_fea_df = hsqlContext.sql(sum_avg_fea_sql)


## fea_dict
feature_dict = sum_avg_fea_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path + key_cal
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)


# save 
save_path = output_feature_hdfs_path + key_cal
keySeconds = sum_avg_fea_df.rdd.map(lambda row: dropFrame(row))
keySeconds.repartition(200).saveAsTextFile(save_path)

sc.stop()
print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
