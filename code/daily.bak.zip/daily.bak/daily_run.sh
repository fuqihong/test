set -e

if [ $# -eq 1 ];then
  etl_day=$1
else
  etl_day=`date +%Y%m%d`
fi

log_fold=/var/log/pyspark/ypdata/daily/${etl_day}

if [ ! -d "$log_fold" ]; then
  mkdir $log_fold
fi

etl_time=`date +%H%M%S`

log_path=$log_fold/${etl_time}.log
echo $log_path

zip -q -r config.zip config

nohup sh dailyYpdata.sh  $log_path  >> ${log_path} 2>&1 &
