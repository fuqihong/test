
#!/usr/bin/python
# encoding:utf-8

from config.config import run_status,output_feature_dict_hdfs_path,output_feature_hdfs_path,input_mid_table_name,dropFrame,yes_time
from config.t01_sql import t01_sql

from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os
reload(sys)
sys.setdefaultencoding('utf-8')


key_cal = 't01'
log_path = sys.argv[1]
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)
print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90

sc = SparkContext(appName= key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)



# mid df
t01_mid_df = hsqlContext.sql("select idcard,"
                           "mec_type as goods_if_subbizcatname,"
                           "case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,"
                           "pay_result as pay_result,"
                           "amt as amt,"
                           "datediff('{current_time}', first_value(repay_tm) over(partition by no_mec,idcard order by repay_tm)) as day_open,"
                           "datediff('{current_time}', repay_tm) as day_pay,"
                           "row_number() over (partition by idcard order by repay_tm desc ) as row_num "
                           "from {mid_table}".format(current_time=yes_time, mid_table=input_mid_table_name))

hsqlContext.registerDataFrameAsTable(t01_mid_df, "mid_df")


## t01 
# cond df
t01_cond_df = hsqlContext.sql("select idcard,"
                           "goods_if_subbizcatname,"
                           "req_if_trademsg,"
                           "pay_result,"
                           "amt,"
                           "case when day_open <= 1 then 1 when day_open <= 7 then 2 when day_open <= 14 then 3 when day_open <= 21 then 4 when day_open <= 30 then 5 when day_open <= 90 then 6 when day_open <= 180 then 7 when day_open <= 360 then 8 else 9 end as day_open,"
                           "case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay,"
                           "case when row_num <= 5 then 1 when row_num <= 20 then 2 when row_num <= 50 then 3 when row_num <= 100 then 4 else 5 end as row_num,"
                           "1 as count_num "
                           "from mid_df  ")
hsqlContext.registerDataFrameAsTable(t01_cond_df, "t01_cond_df")

# fea sql
t01_fea_sql = "select idcard, " + t01_sql + "from t01_cond_df group by idcard"
# fea df
t01_fea_df = hsqlContext.sql(t01_fea_sql)




## sum_avg
#sum_avg_fea_sql = "select idcard, " + sum_avg_sql + "from t01_fea_df"

#sum_avg_fea_df = hsqlContext.sql(sum_avg_fea_sql)

## join
#t01_fea_all_df = t01_fea_df.join(sum_avg_fea_df, "idcard")


feature_dict = t01_fea_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path + key_cal
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)


# save 
save_path = output_feature_hdfs_path + key_cal
keySeconds = t01_fea_df.rdd.map(lambda row: dropFrame(row))
keySeconds.repartition(2000).saveAsTextFile(save_path)

sc.stop()
print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
