#!/usr/bin/python
# encoding:utf-8
from config.count_day_open_sql import count_day_open_4_sql,count_day_open_3_1_sql,count_day_open_3_2_sql,count_day_open_2_1_sql,count_day_open_2_2_sql,count_day_open_1_sql,count_day_open_avg_sql
from config.config import run_status,output_feature_hdfs_path,input_mid_table_name,dropFrame,yes_time,count_distinct_2_sum,output_feature_dict_hdfs_path
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time
import os 


reload(sys)
sys.setdefaultencoding('utf-8')

key_cal = 'countDayOpen'
log_path = sys.argv[1]
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)

print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90

sc = SparkContext(appName= key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)


## count all
midsqlDf = hsqlContext.sql("select idcard,"
                           "no_mec as mec_no,"
                           "mec_type as goods_if_subbizcatname,"
                           "case when flag_error = 1 then 1 when flag_error > 1 then 2 else 3 end as req_if_trademsg,"
                           "pay_result as pay_result,"
                           "datediff('{current_time}', first_value(repay_tm) over(partition by no_mec,idcard order by repay_tm)) as day_open "
                           "from {mid_table}".format(current_time = yes_time, mid_table=input_mid_table_name))

hsqlContext.registerDataFrameAsTable(midsqlDf, "personal_cfsl_loan_deduct_seq_mid")

count_all_sql_df = hsqlContext.sql("select "
						   "idcard, mec_no, goods_if_subbizcatname, req_if_trademsg, pay_result, "
						   "count(1) as temp_count "
                           "from personal_cfsl_loan_deduct_seq_mid"
                           " group by idcard, mec_no, goods_if_subbizcatname, req_if_trademsg, pay_result ")

hsqlContext.registerDataFrameAsTable(count_all_sql_df, "count_all_sql_df")

count_all_df = hsqlContext.sql("select idcard,"
                             "sum(case when goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezzaa,"
                             "sum(case when goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezzab,"
                             "count(distinct case when goods_if_subbizcatname = 'cf' and pay_result =1 then mec_no else null end) as t01dezzac,"
                             "count(distinct case when goods_if_subbizcatname = 'cf' then mec_no else null end) as t01dezzaz,"
                             "sum(case when goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezzba,"
                             "sum(case when goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezzbb,"
                             "count(distinct case when goods_if_subbizcatname ='sl' and pay_result =1 then mec_no else null end) as t01dezzbc,"
                             "count(distinct case when goods_if_subbizcatname ='sl' then mec_no else null end) as t01dezzbz,"
                             "count(distinct case when pay_result =0 and req_if_trademsg = 1 then mec_no else null end) as t01dezzza,"
                             "count(distinct case when pay_result =0 and req_if_trademsg = 2 then mec_no else null end) as t01dezzzb,"
                             "count(distinct case when pay_result =1 then mec_no else null end) as t01dezzzc,"
                             "count(distinct mec_no) as t01dezzzz "
                             "from count_all_sql_df yy group by yy.idcard")


## count_day_open

open_groupby_sql ="""
select idcard,
mec_no,
{groupby_key}
case when day_open <= 1 then 1 when day_open <= 7 then 2 when day_open <= 14 then 3 when day_open <= 21 then 4 when day_open <= 30 then 5 when day_open <= 90 then 6 when day_open <= 180 then 7 when day_open <= 360 then 8 else 9 end as day_open ,
count(1) as temp_count
from  personal_cfsl_loan_deduct_seq_mid 
where day_open <=360
group by 
idcard,
mec_no,
{groupby_key}
case when day_open <= 1 then 1 when day_open <= 7 then 2 when day_open <= 14 then 3 when day_open <= 21 then 4 when day_open <= 30 then 5 
when day_open <= 90 then 6 when day_open <= 180 then 7 when day_open <= 360 then 8 else 9 end
"""

open_groupby_key_4 = "goods_if_subbizcatname,pay_result,req_if_trademsg,"
count_open_4_df = count_distinct_2_sum(open_groupby_sql, open_groupby_key_4, count_day_open_4_sql,hsqlContext)

open_groupby_key_3_1 = "goods_if_subbizcatname,pay_result,"
count_open_3_1_df = count_distinct_2_sum(open_groupby_sql, open_groupby_key_3_1, count_day_open_3_1_sql,hsqlContext)
open_groupby_key_3_2 = "pay_result,req_if_trademsg,"
count_open_3_2_df = count_distinct_2_sum(open_groupby_sql, open_groupby_key_3_2, count_day_open_3_2_sql,hsqlContext)

open_groupby_key_2_1 = "goods_if_subbizcatname,"
count_open_2_1_df = count_distinct_2_sum(open_groupby_sql, open_groupby_key_2_1, count_day_open_2_1_sql,hsqlContext)

open_groupby_key_2_2 = "pay_result,"
count_open_2_2_df = count_distinct_2_sum(open_groupby_sql, open_groupby_key_2_2, count_day_open_2_2_sql,hsqlContext)

open_groupby_key_1 = ""
count_open_1_df = count_distinct_2_sum(open_groupby_sql, open_groupby_key_1, count_day_open_1_sql,hsqlContext)



count_open_df = count_all_df.join(count_open_4_df , "idcard", how = "left_outer").join(count_open_3_1_df , "idcard", \
                  how = "left_outer").join(count_open_3_2_df , "idcard", how = "left_outer").join(count_open_2_1_df , "idcard", 
                  how = "left_outer").join(count_open_2_2_df , "idcard", how = "left_outer").join(count_open_1_df , "idcard", how = "left_outer")


## count_day_open_avg
hsqlContext.registerDataFrameAsTable(count_open_df, "count_open_df")

count_open_avg_df = hsqlContext.sql("select idcard, " + count_day_open_avg_sql + " from count_open_df")


count_open_all_df = count_open_df.join(count_open_avg_df, "idcard")


feature_dict = count_open_all_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path + key_cal 
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)



save_path_1 = output_feature_hdfs_path + key_cal
keySeconds = count_open_all_df.rdd.map(lambda row: dropFrame(row))
keySeconds.repartition(500).saveAsTextFile(save_path_1)

sc.stop()
print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
