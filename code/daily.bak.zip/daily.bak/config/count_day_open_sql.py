
count_day_open_4_sql ="""
sum(case when day_open<=1 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezaaa,
sum(case when day_open<=1 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezaab,
sum(case when day_open<=1 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezaba,
sum(case when day_open<=1 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezabb,
sum(case when day_open<=2 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezbaa,
sum(case when day_open<=2 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezbab,
sum(case when day_open<=2 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezbba,
sum(case when day_open<=2 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezbbb,
sum(case when day_open<=3 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezcaa,
sum(case when day_open<=3 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezcab,
sum(case when day_open<=3 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezcba,
sum(case when day_open<=3 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezcbb,
sum(case when day_open<=4 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezdaa,
sum(case when day_open<=4 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezdab,
sum(case when day_open<=4 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezdba,
sum(case when day_open<=4 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezdbb,
sum(case when day_open<=5 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezeaa,
sum(case when day_open<=5 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezeab,
sum(case when day_open<=5 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezeba,
sum(case when day_open<=5 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezebb,
sum(case when day_open<=6 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezfaa,
sum(case when day_open<=6 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezfab,
sum(case when day_open<=6 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezfba,
sum(case when day_open<=6 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezfbb,
sum(case when day_open<=7 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezgaa,
sum(case when day_open<=7 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezgab,
sum(case when day_open<=7 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezgba,
sum(case when day_open<=7 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezgbb,
sum(case when day_open<=8 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezhaa,
sum(case when day_open<=8 and goods_if_subbizcatname = 'cf' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezhab,
sum(case when day_open<=8 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezhba,
sum(case when day_open<=8 and goods_if_subbizcatname ='sl' and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezhbb
"""


count_day_open_3_1_sql = """
sum(case when day_open<=1 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezaac,
sum(case when day_open<=1 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezabc,
sum(case when day_open<=2 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezbac,
sum(case when day_open<=2 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezbbc,
sum(case when day_open<=3 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezcac,
sum(case when day_open<=3 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezcbc,
sum(case when day_open<=4 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezdac,
sum(case when day_open<=4 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezdbc,
sum(case when day_open<=5 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezeac,
sum(case when day_open<=5 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezebc,
sum(case when day_open<=6 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezfac,
sum(case when day_open<=6 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezfbc,
sum(case when day_open<=7 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezgac,
sum(case when day_open<=7 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezgbc,
sum(case when day_open<=8 and goods_if_subbizcatname = 'cf' and pay_result =1 then 1 else 0 end) as t01dezhac,
sum(case when day_open<=8 and goods_if_subbizcatname ='sl' and pay_result =1 then 1 else 0 end) as t01dezhbc
"""

count_day_open_3_2_sql = """
sum(case when day_open<=1 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezaza,
sum(case when day_open<=1 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezazb,
sum(case when day_open<=2 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezbza,
sum(case when day_open<=2 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezbzb,
sum(case when day_open<=3 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezcza,
sum(case when day_open<=3 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezczb,
sum(case when day_open<=4 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezdza,
sum(case when day_open<=4 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezdzb,
sum(case when day_open<=5 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezeza,
sum(case when day_open<=5 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezezb,
sum(case when day_open<=6 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezfza,
sum(case when day_open<=6 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezfzb,
sum(case when day_open<=7 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezgza,
sum(case when day_open<=7 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezgzb,
sum(case when day_open<=8 and pay_result =0 and req_if_trademsg = 1 then 1 else 0 end) as t01dezhza,
sum(case when day_open<=8 and pay_result =0 and req_if_trademsg = 2 then 1 else 0 end) as t01dezhzb
"""


count_day_open_2_1_sql = """
sum(case when day_open<=1 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezaaz,
sum(case when day_open<=1 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezabz,
sum(case when day_open<=2 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezbaz,
sum(case when day_open<=2 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezbbz,
sum(case when day_open<=3 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezcaz,
sum(case when day_open<=3 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezcbz,
sum(case when day_open<=4 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezdaz,
sum(case when day_open<=4 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezdbz,
sum(case when day_open<=5 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezeaz,
sum(case when day_open<=5 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezebz,
sum(case when day_open<=6 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezfaz,
sum(case when day_open<=6 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezfbz,
sum(case when day_open<=7 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezgaz,
sum(case when day_open<=7 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezgbz,
sum(case when day_open<=8 and goods_if_subbizcatname = 'cf' then 1 else 0 end) as t01dezhaz,
sum(case when day_open<=8 and goods_if_subbizcatname ='sl' then 1 else 0 end) as t01dezhbz
"""

count_day_open_2_2_sql = """
sum(case when day_open<=1 and pay_result =1 then 1 else 0 end) as t01dezazc,
sum(case when day_open<=2 and pay_result =1 then 1 else 0 end) as t01dezbzc,
sum(case when day_open<=3 and pay_result =1 then 1 else 0 end) as t01dezczc,
sum(case when day_open<=4 and pay_result =1 then 1 else 0 end) as t01dezdzc,
sum(case when day_open<=5 and pay_result =1 then 1 else 0 end) as t01dezezc,
sum(case when day_open<=6 and pay_result =1 then 1 else 0 end) as t01dezfzc,
sum(case when day_open<=7 and pay_result =1 then 1 else 0 end) as t01dezgzc,
sum(case when day_open<=8 and pay_result =1 then 1 else 0 end) as t01dezhzc
"""


count_day_open_1_sql = """
sum(case when day_open<=1 then 1 else 0 end) as t01dezazz,
sum(case when day_open<=2 then 1 else 0 end) as t01dezbzz,
sum(case when day_open<=3 then 1 else 0 end) as t01dezczz,
sum(case when day_open<=4 then 1 else 0 end) as t01dezdzz,
sum(case when day_open<=5 then 1 else 0 end) as t01dezezz,
sum(case when day_open<=6 then 1 else 0 end) as t01dezfzz,
sum(case when day_open<=7 then 1 else 0 end) as t01dezgzz,
sum(case when day_open<=8 then 1 else 0 end) as t01dezhzz
"""


count_day_open_avg_sql = """
round ( (case when t01dezazz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezazz/t01dezzzz end),2)  AS t02dezazz_dezzzz ,
round ( (case when t01dezbzz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezbzz/t01dezzzz end),2)  AS t02dezbzz_dezzzz ,
round ( (case when t01dezczz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezczz/t01dezzzz end),2)  AS t02dezczz_dezzzz ,
round ( (case when t01dezdzz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezdzz/t01dezzzz end),2)  AS t02dezdzz_dezzzz ,
round ( (case when t01dezezz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezezz/t01dezzzz end),2)  AS t02dezezz_dezzzz ,
round ( (case when t01dezfzz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezfzz/t01dezzzz end),2)  AS t02dezfzz_dezzzz ,
round ( (case when t01dezgzz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezgzz/t01dezzzz end),2)  AS t02dezgzz_dezzzz ,
round ( (case when t01dezhzz IS NULL THEN NULL when t01dezzzz IS NULL THEN NULL when t01dezzzz=0 THEN 0 ELSE t01dezhzz/t01dezzzz end),2)  AS t02dezhzz_dezzzz 
"""
