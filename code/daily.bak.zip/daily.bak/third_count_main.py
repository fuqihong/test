#!/usr/bin/python
# encoding:utf-8
import os 
from config.third_count_sql import third_count_1_sql, third_count_2_sql,third_count_3_sql,third_count_4_sql
from config.config import run_status, output_feature_dict_hdfs_path,output_feature_hdfs_path,input_mid_table_name,dropFrame,yes_time,count_distinct_2_sum
from pyspark import SparkContext
from pyspark.sql import HiveContext
import sys
import re
import time

reload(sys)
sys.setdefaultencoding('utf-8')



key_cal = 'third_count'
log_path = sys.argv[1]
run_status(key_cal, log_path, output_feature_hdfs_path, output_feature_dict_hdfs_path)

print key_cal + "_sql_daily" + " run " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90


sc = SparkContext(appName=key_cal + "_sql_daily")
hsqlContext = HiveContext(sc)



kkOrgCountInitDf = hsqlContext.sql("select idcard, "
                                   "mec_type,"
                                   "datediff('{current_time}',repay_tm) as day_pay,"
                                   "no_mec,"
                                   "pay_result,"
                                   "count(1) as times "
                                   "from {mid_table} group by idcard,mec_type,datediff('{current_time}',repay_tm),no_mec,pay_result".format(current_time=yes_time, mid_table=input_mid_table_name))

hsqlContext.registerDataFrameAsTable(kkOrgCountInitDf, "kkOrgCountInit")

kkOrgCountMidDf = hsqlContext.sql("select aa.idcard,"
                                  "aa.mec_type,"
                                  "case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 "
                                  "then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end as day_pay,"
                                  "aa.no_mec,"
                                  "aa.pay_result,"
                                  "case when times > 100 then 5 when times > 50 then 4 when times > 10 then 3 when times > 0 then 2 else 1 end as times, count(1) as count_temp from kkOrgCountInit aa"
                                  " group by "
                                  "aa.idcard,"
                                  "aa.mec_type,"
                                  "case when day_pay <= 1 then 1 when day_pay <= 7 then 2 when day_pay <= 14 then 3 when day_pay <= 21 then 4 when day_pay <= 30 "
                                  "then 5 when day_pay <= 90 then 6 when day_pay <= 180 then 7 when day_pay <= 360 then 8 else 9 end,"
                                  "aa.no_mec,"
                                  "aa.pay_result,"
                                  "case when times > 100 then 5 when times > 50 then 4 when times > 10 then 3 when times > 0 then 2 else 1 end")

hsqlContext.registerDataFrameAsTable(kkOrgCountMidDf, "kkOrgCountMid")



groupby_sql = """
select idcard,
no_mec,
{groupby_key},
count(1) as temp_count 
from  kkOrgCountMid 
group by idcard, no_mec, 
{groupby_key} 
"""


groupby_key_1 = "mec_type, day_pay, pay_result, times"
third_count_1_df = count_distinct_2_sum(groupby_sql, groupby_key_1, third_count_1_sql, hsqlContext)

groupby_key_2 = "mec_type, pay_result, times"
third_count_2_df = count_distinct_2_sum(groupby_sql, groupby_key_2, third_count_2_sql, hsqlContext)

groupby_key_3 = "day_pay, pay_result, times "
third_count_3_df = count_distinct_2_sum(groupby_sql, groupby_key_3, third_count_3_sql, hsqlContext)

groupby_key_4 = "pay_result, times"
third_count_4_df = count_distinct_2_sum(groupby_sql, groupby_key_4, third_count_4_sql, hsqlContext)

third_count_df = third_count_1_df.join(third_count_2_df, "idcard").join(third_count_3_df, "idcard").join(third_count_4_df, "idcard")


feature_dict = third_count_df.columns
feature_dict_str = ','.join(feature_dict)
feature_path = output_feature_dict_hdfs_path +  key_cal
sc.parallelize([feature_dict_str]).repartition(1).saveAsTextFile(feature_path)

save_path = output_feature_hdfs_path + key_cal
keys = third_count_df.rdd.map(lambda row: dropFrame(row))
keys.repartition(500).saveAsTextFile(save_path)
sc.stop()


print key_cal + "_sql_daily" + " success " + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))  +  "*"*90
